import numpy as np
from transforms import FFTTransformer

def fix_rolling_shutter(original_img, shifted_img):
    orig = np.asarray(original_img, dtype=np.float64)
    shift = np.asarray(shifted_img, dtype=np.float64)

    H, W = orig.shape()
    engine = FFTTransformer()

    ansArray = np.zeros(H)

    for r in range(H):
        row_org = orig[r, :]
        row_shift = shift[r, :]

        F_org = engine.transform(row_org)
        F_shifted = engine.transform(row_shift)

        Multi = F_org*np.conj(F_shifted)

        ans = engine.inverse(Multi).real
        shiftAmount = np.argmax(ans)

        ansArray[r, :] = np.roll(row_shift, -shiftAmount)

    return ansArray




W = 4
engine = FFTTransformer() # Just to load it
original = np.array([
    [10, 50, 10, 10],
    [20, 60, 20, 20],
    [30, 70, 30, 30],
    [40, 80, 40, 40]
])

# Shift row 0 by 1, row 1 by 2, row 2 by 3
shifted = np.array([
    [10, 10, 50, 10], # Shifted right by 1
    [20, 20, 60, 20], # Shifted right by 2
    [70, 30, 30, 30], # Shifted right by 3
    [40, 80, 40, 40]  # No shift
])

fixed = fix_rolling_shutter(original, shifted)

print("Original:\n", original)
print("\nShifted:\n", shifted)
print("\nFixed (Should match Original):\n", fixed.astype(int))