import numpy as np
from transforms import FFTTransformer, next_power_of_two

def multiply_digit_arrays(A, B):
    minLength = len(A) + len(B) -1
    N = next_power_of_two(minLength)

    APadded = np.zeros(N, dtype=np.complex128)
    BPadded = np.zeros(N, dtype=np.complex128)

    APadded[:len(A)] = A
    BPadded[:len(B)] = B

    engine = FFTTransformer()

    F_A = engine.transform(APadded)
    F_B = engine.transform(BPadded)

    mult = F_A*F_B

    multRaw = engine.inverse(mult)

    C = np.round(multRaw).astype(np.int64)

    result = []
    carry = 0
    for i in range(minLength):
        total = C[i] + carry
        result.append(total%10)
        carry = total//10

    while carry>0:
        result.append(carry%10)
        carry //=10
    while len(result) > 1 and result[-1] == 0:
        result.pop()
    return result

A = [3, 2, 1]  # Represents 123
B = [5, 4]     # Represents 45
print("Result 1:", multiply_digit_arrays(A, B))  # Expected: [5, 3, 5, 5]

A2 = [9, 9, 9] # Represents 999
B2 = [9, 9]    # Represents 99
print("Result 2:", multiply_digit_arrays(A2, B2)) # Expected: [1, 0, 9, 8, 9]