import numpy as np
from transforms import FFTTransformer, next_power_of_two

def weighted_poly_mult(P, Q, W):
    p = np.array(P)[::-1]
    q = np.array(Q)[::-1]
    w = np.array(W)[::-1]

    pw = p*w 

    minLength = len(p) + len(q)-1
    N = next_power_of_two(minLength)

    pwPad = np.zeros(N, dtype=np.complex128)
    qPad = np.zeros(N, dtype=np.complex128)

    pwPad[:len(pw)]=pw
    qPad[:len(q)]=Q

    engine = FFTTransformer()

    F_pw = engine.transform(pwPad)
    F_q = engine.transform(qPad)

    FR = F_pw*F_q

    R_raw = engine.inverse(FR)

    R = np.round(R_raw.real).astype(np.int64)[:minLength]

    return R[::-1].tolist()


# --- Test the Code ---
P1, Q1, W1 = [1, 3, 2], [4, 1], [3, 2, 1]
print("Result 1:", weighted_poly_mult(P1, Q1, W1)) 
# Expected: [12, 27, 14, 2]

P2, Q2, W2 = [1, 3, 2, 6, 7], [4, 1], [3, 2, 1, 5, 6]
print("Result 2:", weighted_poly_mult(P2, Q2, W2))