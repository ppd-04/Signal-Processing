import numpy as np
from transforms import FFTTransformer

def decryptLogo(encrypted_img):
    img = np.asarray(encrypted_img, dtype=np.float64)
    H, W = img.shape()
    engine = FFTTransformer()

    key_idx = np.argmin(img[:, 0])
    keyRow = img[key_idx, :]

    F_key = engine.transform(keyRow)

    decrypted = np.zeros_like(img)
    for r in range(H):
        if r == key_idx:
            decrypted[r, :] = keyRow
        else:
            F_enc = engine.transform(img[r, :])
            F_org = F_enc/F_key
            decrypted[r, :] = engine.inverse(F_org).real
    decrypted = np.clip(decrypted, ,0, 255)
    return decrypted, key_idx