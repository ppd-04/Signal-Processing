import numpy as np

# arr = np.array([1,2])
# arr2 = np.zeros(4)
# arr2[2:] = arr
# print(arr2)

arr = np.array([[1,2],[3,4]])
arr2 = np.zeros((4,4))
arr2[:2, :2] = arr
print(arr2)

