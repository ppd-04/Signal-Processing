import numpy as np
import matplotlib.pyplot as plt

# ==================================================
# Signal and Sampling
# ==================================================
f = 2      # Hz
fs = 10    # Sampling rate
Ts = 1/fs  # 0.1 seconds between samples
duration = 1.0

t_cont = np.arange(0, duration, 0.0001)
x_cont = np.sin(2 * np.pi * f * t_cont)

t_s = np.arange(0, duration, Ts)   # [0, 0.1, 0.2, ..., 0.9]
x_s = np.sin(2 * np.pi * f * t_s)
N = len(t_s)  # 10 samples

print(f"Number of samples: {N}")
print(f"Sample values: {np.round(x_s, 3)}")

# ==================================================
# Compute individual sinc contributions
# ==================================================
# Each sample n generates: x[n] * sinc((t - n*Ts) / Ts)
sinc_contributions = np.zeros((N, len(t_cont)))

for n in range(N):
    sinc_arg = (t_cont - t_s[n]) / Ts
    sinc_contributions[n] = x_s[n] * np.sinc(sinc_arg)

# Sum all contributions
x_reconstructed = np.sum(sinc_contributions, axis=0)
# axis=0 means sum along rows → for each time point, sum all sinc values

# ==================================================
# PLOT 1: Show each sinc contribution separately
# ==================================================
fig, axes = plt.subplots(3, 1, figsize=(14, 14))

# --- Individual sinc functions ---
colors = plt.cm.tab10(np.linspace(0, 1, N))  # Different color for each

for n in range(N):
    axes[0].plot(t_cont, sinc_contributions[n], color=colors[n], 
                  linewidth=1, alpha=0.7, label=f'n={n}, x[{n}]={x_s[n]:.2f}')

axes[0].stem(t_s, x_s, linefmt='k-', markerfmt='ko', basefmt='k-')
axes[0].set_title(f'Individual Sinc Contributions (Each sample creates one sinc)')
axes[0].set_xlabel('Time (s)')
axes[0].set_ylabel('Amplitude')
axes[0].legend(fontsize=7, loc='upper right', ncol=2)
axes[0].grid(True, alpha=0.3)
axes[0].set_ylim(-1.5, 1.5)

# --- Show progressive building of the reconstruction ---
axes[1].plot(t_cont, x_cont, 'b-', linewidth=3, alpha=0.3, label='Original')

# Add sincs one by one
partial_sums = [1, 3, 5, 7, N]  # Show reconstruction with 1, 3, 5, 7, all sincs
alphas = [0.3, 0.4, 0.5, 0.7, 1.0]

for num_sincs, alpha in zip(partial_sums, alphas):
    partial = np.sum(sinc_contributions[:num_sincs], axis=0)
    axes[1].plot(t_cont, partial, linewidth=1.5, alpha=alpha,
                  label=f'Sum of first {num_sincs} sincs')

axes[1].stem(t_s, x_s, linefmt='k-', markerfmt='ko', basefmt='k-')
axes[1].set_title('Progressive Reconstruction: Adding Sincs One by One')
axes[1].set_xlabel('Time (s)')
axes[1].set_ylabel('Amplitude')
axes[1].legend(fontsize=8)
axes[1].grid(True, alpha=0.3)

# --- Final reconstruction vs original ---
error = x_cont - x_reconstructed
axes[2].plot(t_cont, x_cont, 'b-', linewidth=2, alpha=0.5, label='Original')
axes[2].plot(t_cont, x_reconstructed, 'r--', linewidth=2, label='Sinc Reconstruction')
axes[2].stem(t_s, x_s, linefmt='k-', markerfmt='ko', basefmt='k-', label='Samples')
axes[2].fill_between(t_cont, x_cont, x_reconstructed, alpha=0.2, color='red', label='Error region')
axes[2].set_title(f'Final Reconstruction | RMS Error = {np.sqrt(np.mean(error**2)):.8f}')
axes[2].set_xlabel('Time (s)')
axes[2].set_ylabel('Amplitude')
axes[2].legend(fontsize=8)
axes[2].grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

# ==================================================
# BONUS: Show sinc function properties
# ==================================================
fig, ax = plt.subplots(figsize=(12, 5))

t_demo = np.arange(-3, 4, 0.001)  # From -3 to +4

# Show a single sinc centered at 0
sinc_demo = np.sinc(t_demo)
ax.plot(t_demo, sinc_demo, 'b-', linewidth=2, label='sinc(t/Ts) centered at n=0')

# Mark the key properties
ax.plot(0, 1, 'ro', markersize=15, zorder=5)
ax.annotate('sinc(0) = 1\n(passes through\nits own sample)', 
            xy=(0, 1), xytext=(0.5, 1.2), fontsize=10,
            arrowprops=dict(arrowstyle='->', color='red'))

for k in [-3, -2, -1, 1, 2, 3]:
    ax.plot(k, 0, 'go', markersize=10, zorder=5)

ax.annotate('sinc(±1,±2,±3,...) = 0\n(zero at all other sample points)', 
            xy=(1, 0), xytext=(1.5, 0.4), fontsize=10,
            arrowprops=dict(arrowstyle='->', color='green'))

ax.set_title('The sinc Function: Key to Perfect Reconstruction', fontsize=14)
ax.set_xlabel('t / Ts (normalized time)')
ax.set_ylabel('sinc(t/Ts)')
ax.grid(True, alpha=0.3)
ax.legend(fontsize=11)
ax.axhline(y=0, color='k', linewidth=0.5)
ax.axvline(x=0, color='k', linewidth=0.5)

plt.tight_layout()
plt.show()