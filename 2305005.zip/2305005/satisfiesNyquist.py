import numpy as np 
import matplotlib.pyplot as plt

fmax= 200
fs = 3000
if fs > 2*fmax:
    print("yes")
else:
    print("NO")
