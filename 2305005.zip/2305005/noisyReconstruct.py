import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d, CubicSpline, make_interp_spline

np.random.seed(42)

# ==================================================
# Clean signal
# ==================================================
f = 3
fs = 20
Ts = 1 / fs
T = 1

t_cont = np.arange(0, T, 0.0001)
x_cont = np.sin(2 * np.pi * f * t_cont)

t_s = np.arange(0, T, Ts)
x_clean = np.sin(2 * np.pi * f * t_s)

# ==================================================
# Add noise to samples
# ==================================================
noise_levels = [0.0, 0.05, 0.15, 0.3]
# 0.0  = no noise (perfect)
# 0.05 = small noise (5% of signal amplitude)
# 0.15 = moderate noise
# 0.3  = heavy noise

fig, axes = plt.subplots(len(noise_levels), 3, figsize=(18, 4 * len(noise_levels)))

for row, noise_std in enumerate(noise_levels):
    # Add Gaussian noise to samples
    noise = np.random.normal(0, noise_std, len(x_clean))
    # np.random.normal(mean, std, size)
    # Gaussian noise: most values near 0, spread controlled by std
    x_noisy = x_clean + noise
    
    # ----- Reconstruct with three methods -----
    
    # Linear: moderate smoothing, handles noise OK
    f_linear = interp1d(t_s, x_noisy, kind='linear', fill_value='extrapolate')
    x_recon_linear = f_linear(t_cont)
    
    # Cubic: less smoothing, can amplify noise
    f_cubic = interp1d(t_s, x_noisy, kind='cubic', fill_value='extrapolate')
    x_recon_cubic = f_cubic(t_cont)
    
    # High-order spline: least smoothing, most noise amplification
    # k=5 quintic spline
    try:
        bs = make_interp_spline(t_s, x_noisy, k=5)
        x_recon_spline5 = bs(t_cont)
    except:
        x_recon_spline5 = x_recon_cubic  # Fallback
    
    recon_methods = [
        ('Linear', x_recon_linear, 'green'),
        ('Cubic', x_recon_cubic, 'orange'),
        ('Quintic Spline (k=5)', x_recon_spline5, 'red')
    ]
    
    for col, (name, x_recon, color) in enumerate(recon_methods):
        rms = np.sqrt(np.mean((x_cont - x_recon) ** 2))
        
        axes[row][col].plot(t_cont, x_cont, 'b-', linewidth=2, alpha=0.3, label='True signal')
        axes[row][col].plot(t_cont, x_recon, color=color, linewidth=1.5, label=f'{name} recon')
        axes[row][col].stem(t_s, x_noisy, linefmt='k-', markerfmt='ko', 
                             basefmt='k-', label='Noisy samples')
        axes[row][col].set_title(f'Noise σ={noise_std} | {name} | RMS={rms:.4f}', fontsize=10)
        axes[row][col].set_xlabel('Time (s)')
        axes[row][col].legend(fontsize=7)
        axes[row][col].grid(True, alpha=0.3)
        axes[row][col].set_xlim(0, 0.8)
        axes[row][col].set_ylim(-1.8, 1.8)

plt.tight_layout()
plt.show()

# ==================================================
# Summary analysis
# ==================================================
print("\n" + "=" * 70)
print("KEY OBSERVATION:")
print("=" * 70)
print("""
With NO noise:    All methods work well. Higher-order = better.
With SMALL noise: Higher-order methods still slightly better.
With HEAVY noise: Higher-order methods AMPLIFY noise!
                  → They try to pass through every noisy sample perfectly,
                    creating wild oscillations between samples.
                  → Simpler methods (linear) smooth out the noise.

LESSON: In practice, you must MATCH the interpolation method to the data quality.
        - Clean data → Use high-order methods (cubic, sinc)
        - Noisy data → Use simpler methods OR filter first, then reconstruct
""")