import numpy as np 
import matplotlib.pyplot as plt

f = 5
fs = 20

t_cont = np.linspace(0, 1, 1000)
x_cont = np.sin(2*np.pi*f*t_cont)

t_sample = np.arange(0, 1, 1/fs)
x_sample = np.sin(2*np.pi*f*t_sample)

plt.plot(t_cont, x_cont, label = "COnt")
plt.stem(t_sample, x_sample)
plt.xlabel("time")
plt.ylabel("amp")
plt.legend()
plt.show()