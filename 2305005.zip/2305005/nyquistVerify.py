import numpy as np
import matplotlib.pyplot as plt

def analyze_sampling(frequencies, amplitudes, sampling_rates, duration=1.0):
    """
    Complete sampling analysis tool.
    
    Parameters:
    - frequencies: list of signal frequency components (Hz)
    - amplitudes: list of corresponding amplitudes
    - sampling_rates: list of sampling rates to test
    - duration: signal duration in seconds
    """
    
    f_max = max(frequencies)
    nyquist_rate = 2 * f_max
    
    print("=" * 60)
    print(f"Signal Components: {list(zip(frequencies, amplitudes))}")
    print(f"Maximum Frequency: {f_max} Hz")
    print(f"Nyquist Rate: {nyquist_rate} Hz")
    print("=" * 60)
    
    # Generate "continuous" signal
    fs_cont = 10000  # Very high rate to simulate continuous
    t_cont = np.arange(0, duration, 1/fs_cont)
    x_cont = sum(a * np.sin(2 * np.pi * f * t_cont) for f, a in zip(frequencies, amplitudes))
    
    fig, axes = plt.subplots(len(sampling_rates), 2, figsize=(14, 4 * len(sampling_rates)))
    if len(sampling_rates) == 1:
        axes = [axes]  # Make it iterable
    
    for i, fs in enumerate(sampling_rates):
        # ---- Sample ----
        Ts = 1 / fs
        t_s = np.arange(0, duration, Ts)
        x_s = sum(a * np.sin(2 * np.pi * f * t_s) for f, a in zip(frequencies, amplitudes))
        N = len(x_s)
        
        # ---- FFT of sampled signal ----
        X = np.fft.fft(x_s)
        freqs_fft = np.fft.fftfreq(N, Ts)
        mag = np.abs(X) / N * 2
        pos_mask = freqs_fft > 0
        freqs_pos = freqs_fft[pos_mask]
        mag_pos = mag[pos_mask]
        
        # ---- Detect peaks ----
        threshold = 0.05 * max(mag_pos)  # 5% of max
        peak_indices = []
        for j in range(1, len(mag_pos) - 1):
            if mag_pos[j] > threshold and mag_pos[j] > mag_pos[j-1] and mag_pos[j] > mag_pos[j+1]:
                peak_indices.append(j)
        
        detected_freqs = [freqs_pos[j] for j in peak_indices]
        
        # ---- Check for aliasing ----
        is_aliased = fs < nyquist_rate
        
        # Calculate expected aliased frequencies
        aliased_freqs = []
        for f in frequencies:
            # Fold frequency into [0, fs/2]
            f_folded = f % fs
            if f_folded > fs / 2:
                f_folded = fs - f_folded
            aliased_freqs.append(round(f_folded, 1))
        
        status = "⚠️ ALIASING" if is_aliased else "✅ SAFE"
        
        # ---- Time domain plot ----
        axes[i][0].plot(t_cont, x_cont, 'b-', alpha=0.4, linewidth=1, label='Original')
        axes[i][0].stem(t_s, x_s, linefmt='r-', markerfmt='ro', basefmt='k-', label=f'Sampled (fs={fs} Hz)')
        axes[i][0].set_title(f'{status} | fs = {fs} Hz (Nyquist rate = {nyquist_rate} Hz)')
        axes[i][0].set_xlabel('Time (s)')
        axes[i][0].set_ylabel('Amplitude')
        axes[i][0].legend(fontsize=8)
        axes[i][0].grid(True)
        axes[i][0].set_xlim(0, min(0.2, duration))  # Show first 200ms
        
        # ---- Frequency domain plot ----
        axes[i][1].stem(freqs_pos, mag_pos, linefmt='r-', markerfmt='r.', basefmt='k-')
        # Mark original frequencies
        for f in frequencies:
            axes[i][1].axvline(x=f, color='blue', linestyle='--', alpha=0.5)
        axes[i][1].set_title(f'Spectrum | Detected: {[round(f,1) for f in detected_freqs]} Hz | Expected alias: {aliased_freqs}')
        axes[i][1].set_xlabel('Frequency (Hz)')
        axes[i][1].set_ylabel('Magnitude')
        axes[i][1].set_xlim(0, fs/2)
        axes[i][1].grid(True)
        
        # ---- Print analysis ----
        print(f"\nfs = {fs} Hz | Status: {status}")
        print(f"  Original frequencies: {frequencies}")
        print(f"  Apparent frequencies after sampling: {aliased_freqs}")
        print(f"  Detected in FFT: {[round(f,1) for f in detected_freqs]}")
    
    plt.tight_layout()
    plt.show()

# ---- Run the analysis ----
frequencies = [10, 30, 70]
amplitudes = [1.0, 0.7, 0.5]
sampling_rates = [200, 150, 100, 50]  # Various rates to test

analyze_sampling(frequencies, amplitudes, sampling_rates, duration=0.5)