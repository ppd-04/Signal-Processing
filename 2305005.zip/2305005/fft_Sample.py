import numpy as np
import matplotlib.pyplot as plt

# ---- Signal parameters ----
fs = 200       # Sampling frequency
T = 1          # Duration in seconds
N = fs * T     # Total number of samples = 200

t = np.arange(0, T, 1/fs)  # Time vector: 200 points from 0 to 0.995

# ---- Generate the signal ----
f1, f2, f3 = 20, 50, 80    # Three frequency components
A1, A2, A3 = 3, 1.5, 1     # Their amplitudes
x = A1*np.sin(2*np.pi*f1*t) + A2*np.sin(2*np.pi*f2*t) + A3*np.sin(2*np.pi*f3*t)

# ---- Compute FFT ----
X = np.fft.fft(x)              # Complex FFT output
frequencies = np.fft.fftfreq(N, d=1/fs)  # Frequency axis
# N = number of samples, d = sampling period

magnitude = np.abs(X) / N      # Magnitude (normalized by N)
# We divide by N to get correct amplitude scaling

# ---- Plot only positive frequencies ----
# FFT output is symmetric, so we only need the first half
positive_mask = frequencies >= 0
freq_positive = frequencies[positive_mask]
mag_positive = magnitude[positive_mask] * 2  # Multiply by 2 because energy is split between +/- freq
# (except DC component, but we don't have DC here)

fig, axes = plt.subplots(2, 1, figsize=(12, 8))

# Time domain
axes[0].plot(t, x, 'b-')
axes[0].set_title('Time Domain Signal')
axes[0].set_xlabel('Time (seconds)')
axes[0].set_ylabel('Amplitude')
axes[0].grid(True)

# Frequency domain
axes[1].stem(freq_positive, mag_positive, linefmt='r-', markerfmt='ro', basefmt='k-')
axes[1].set_title(f'Magnitude Spectrum (fs = {fs} Hz, N = {N} samples)')
axes[1].set_xlabel('Frequency (Hz)')
axes[1].set_ylabel('Amplitude')
axes[1].grid(True)
axes[1].set_xlim(0, fs/2)  # Only show up to Nyquist frequency

plt.tight_layout()
plt.show()

# ---- Print detected peaks ----
threshold = 0.1  # Ignore very small values
peak_indices = np.where(mag_positive > threshold)[0]
print("Detected frequency components:")
for idx in peak_indices:
    print(f"  Frequency: {freq_positive[idx]:.1f} Hz, Amplitude: {mag_positive[idx]:.2f}")