import numpy as np
import matplotlib.pyplot as plt

# ==================================================
# Signal parameters
# ==================================================
f_signal = 10  # Hz
nyquist_rate = 2 * f_signal  # 20 Hz

# "Continuous" reference
t_cont = np.arange(0, 1, 0.0001)
x_cont = np.sin(2 * np.pi * f_signal * t_cont)

# Sampling rates to test
# Some below Nyquist (will fail), some above (will work)
sampling_rates = [15, 20, 25, 40, 100]

# ==================================================
# Sinc reconstruction function
# ==================================================
def sinc_reconstruct(t_recon, t_samp, x_samp, Ts):
    x_recon = np.zeros(len(t_recon))
    for n in range(len(t_samp)):
        x_recon += x_samp[n] * np.sinc((t_recon - t_samp[n]) / Ts)
    return x_recon

# ==================================================
# Reconstruct at each sampling rate
# ==================================================
fig, axes = plt.subplots(len(sampling_rates), 1, figsize=(14, 4 * len(sampling_rates)))
rms_errors = []

for i, fs in enumerate(sampling_rates):
    Ts = 1 / fs
    t_s = np.arange(0, 1, Ts)
    x_s = np.sin(2 * np.pi * f_signal * t_s)
    
    # Reconstruct
    x_recon = sinc_reconstruct(t_cont, t_s, x_s, Ts)
    
    # Error
    rms = np.sqrt(np.mean((x_cont - x_recon) ** 2))
    rms_errors.append(rms)
    
    # Determine status
    if fs < nyquist_rate:
        status = f"❌ BELOW Nyquist (fs={fs} < {nyquist_rate})"
        color = 'red'
    elif fs == nyquist_rate:
        status = f"⚠️ EXACTLY at Nyquist (fs={fs} = {nyquist_rate})"
        color = 'orange'
    else:
        ratio = fs / nyquist_rate
        status = f"✅ ABOVE Nyquist ({ratio:.1f}× oversampled)"
        color = 'green'
    
    # Plot
    axes[i].plot(t_cont, x_cont, 'b-', linewidth=2, alpha=0.4, label='Original')
    axes[i].plot(t_cont, x_recon, color=color, linewidth=1.5, 
                  label=f'Reconstructed (fs={fs} Hz)')
    axes[i].stem(t_s, x_s, linefmt='k-', markerfmt='ko', basefmt='k-', 
                  label=f'{len(t_s)} samples')
    axes[i].set_title(f'fs = {fs} Hz | {status} | RMS Error = {rms:.6f}')
    axes[i].set_xlabel('Time (s)')
    axes[i].set_ylabel('Amplitude')
    axes[i].legend(loc='upper right', fontsize=8)
    axes[i].grid(True, alpha=0.3)
    axes[i].set_xlim(0, 0.5)

plt.tight_layout()
plt.show()

# ==================================================
# Plot RMS Error vs Sampling Rate
# ==================================================
plt.figure(figsize=(10, 6))
plt.plot(sampling_rates, rms_errors, 'bo-', markersize=10, linewidth=2)
plt.axvline(x=nyquist_rate, color='r', linestyle='--', linewidth=2, 
            label=f'Nyquist rate = {nyquist_rate} Hz')
plt.xlabel('Sampling Rate (Hz)', fontsize=12)
plt.ylabel('RMS Reconstruction Error', fontsize=12)
plt.title('Reconstruction Error vs Sampling Rate', fontsize=14)
plt.legend(fontsize=12)
plt.grid(True, alpha=0.3)
plt.yscale('log')  # Log scale to see the huge difference

# Annotate each point
for fs, err in zip(sampling_rates, rms_errors):
    plt.annotate(f'fs={fs}\nerr={err:.2e}', (fs, err), 
                 textcoords="offset points", xytext=(10, 10), fontsize=9)

plt.tight_layout()
plt.show()

# Print summary
print("\nSummary:")
print(f"{'fs (Hz)':>8} {'RMS Error':>15} {'Status':>30}")
print("-" * 55)
for fs, err in zip(sampling_rates, rms_errors):
    if fs < nyquist_rate:
        s = "Below Nyquist - ALIASED"
    elif fs == nyquist_rate:
        s = "At Nyquist - Marginal"
    else:
        s = "Above Nyquist - Good"
    print(f"{fs:>8} {err:>15.8f} {s:>30}")