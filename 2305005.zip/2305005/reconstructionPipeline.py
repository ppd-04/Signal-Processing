import numpy as np
import matplotlib.pyplot as plt
from scipy import signal as sig
from scipy.interpolate import CubicSpline

# ============================================================
# STAGE 0: Original Continuous Signal
# ============================================================
fs_continuous = 50000  # Simulated continuous (50 kHz)
T = 0.01  # 10 ms
t = np.arange(0, T, 1/fs_continuous)

# Complex signal with frequencies from low to high
frequencies = [100, 300, 800, 1500, 3000, 5500, 8000]
amplitudes  = [1.0, 0.8, 0.6, 0.5, 0.4, 0.3, 0.2]

x_original = np.zeros(len(t))
for f, a in zip(frequencies, amplitudes):
    x_original += a * np.sin(2 * np.pi * f * t)

print("=" * 60)
print("COMPLETE ADC/DAC PIPELINE SIMULATION")
print("=" * 60)
print(f"\nOriginal signal frequencies: {frequencies} Hz")
print(f"Maximum frequency: {max(frequencies)} Hz")

# ============================================================
# STAGE 1: Anti-Aliasing Filter
# ============================================================
fs_target = 10000  # Target sampling rate: 10 kHz
f_nyquist = fs_target / 2  # 5000 Hz

print(f"\nTarget sampling rate: {fs_target} Hz")
print(f"Nyquist frequency: {f_nyquist} Hz")
print(f"Frequencies below Nyquist: {[f for f in frequencies if f < f_nyquist]}")
print(f"Frequencies above Nyquist (will be filtered): {[f for f in frequencies if f >= f_nyquist]}")

# Design anti-aliasing filter (Butterworth, order 6)
order = 6
Wn = f_nyquist / (fs_continuous / 2)  # Normalized cutoff
b, a = sig.butter(order, Wn, btype='low')

# Apply filter
x_filtered = sig.filtfilt(b, a, x_original)

# ============================================================
# STAGE 2: Sampling
# ============================================================
downsample_factor = fs_continuous // fs_target  # = 5
t_sampled = t[::downsample_factor]
x_sampled = x_filtered[::downsample_factor]
N_samples = len(x_sampled)

print(f"\nAfter sampling: {N_samples} samples")

# ============================================================
# STAGE 3: Quantization
# ============================================================
num_bits = 8
num_levels = 2 ** num_bits  # 256 levels

x_min = np.min(x_sampled) - 0.1  # Add small margin
x_max = np.max(x_sampled) + 0.1
delta = (x_max - x_min) / num_levels  # Step size

# Quantize
x_normalized = (x_sampled - x_min) / delta
x_quantized_idx = np.clip(np.floor(x_normalized).astype(int), 0, num_levels - 1)
x_quantized = x_min + x_quantized_idx * delta + delta / 2

# Quantization noise
quant_noise = x_sampled - x_quantized
SQNR = 10 * np.log10(np.mean(x_sampled**2) / np.mean(quant_noise**2))

print(f"\nQuantization: {num_bits} bits ({num_levels} levels)")
print(f"Step size (Δ): {delta:.6f}")
print(f"SQNR: {SQNR:.2f} dB (theoretical: {6.02*num_bits + 1.76:.2f} dB)")

# ============================================================
# STAGE 4: Reconstruction (DAC side)
# ============================================================
# Use cubic spline for practical reconstruction
cs = CubicSpline(t_sampled, x_quantized)
x_reconstructed = cs(t)

# ============================================================
# STAGE 5: Error Analysis
# ============================================================
# Compare reconstructed signal with original
total_error = x_original - x_reconstructed

# Break down error sources
filter_error = x_original - x_filtered          # Lost high frequencies
sampling_error = x_filtered - cs(t)              # Reconstruction imperfection
# (quantization error is already computed)

rms_total = np.sqrt(np.mean(total_error ** 2))
rms_filter = np.sqrt(np.mean(filter_error ** 2))
rms_recon = np.sqrt(np.mean(sampling_error ** 2))
rms_quant = np.sqrt(np.mean(quant_noise ** 2))

# ============================================================
# MEGA PLOT: The Complete Pipeline
# ============================================================
fig, axes = plt.subplots(6, 1, figsize=(16, 24))

# Plot 0: Original signal
axes[0].plot(t * 1000, x_original, 'b-', linewidth=1)
axes[0].set_title('Stage 0: Original Continuous Signal', fontsize=13)
axes[0].set_xlabel('Time (ms)')
axes[0].set_ylabel('Amplitude')
axes[0].grid(True, alpha=0.3)

# Plot 1: After anti-aliasing filter
axes[1].plot(t * 1000, x_original, 'b-', alpha=0.3, label='Before filter')
axes[1].plot(t * 1000, x_filtered, 'g-', linewidth=1.5, label='After filter')
axes[1].set_title(f'Stage 1: Anti-Aliasing Filter (Butterworth, order {order}, cutoff {f_nyquist} Hz)', fontsize=13)
axes[1].set_xlabel('Time (ms)')
axes[1].set_ylabel('Amplitude')
axes[1].legend()
axes[1].grid(True, alpha=0.3)

# Plot 2: Sampling
axes[2].plot(t * 1000, x_filtered, 'g-', alpha=0.3, label='Filtered signal')
axes[2].stem(t_sampled * 1000, x_sampled, linefmt='r-', markerfmt='ro', 
              basefmt='k-', label=f'Samples (fs={fs_target} Hz)')
axes[2].set_title(f'Stage 2: Sampling at {fs_target} Hz ({N_samples} samples)', fontsize=13)
axes[2].set_xlabel('Time (ms)')
axes[2].set_ylabel('Amplitude')
axes[2].legend()
axes[2].grid(True, alpha=0.3)

# Plot 3: Quantization
axes[3].stem(t_sampled * 1000, x_sampled, linefmt='r-', markerfmt='ro', 
              basefmt='k-', label='Before quantization')
axes[3].stem(t_sampled * 1000, x_quantized, linefmt='m-', markerfmt='ms', 
              basefmt='k-', label=f'After quantization ({num_bits} bits)')
axes[3].set_title(f'Stage 3: Quantization ({num_bits} bits, {num_levels} levels, SQNR={SQNR:.1f} dB)', fontsize=13)
axes[3].set_xlabel('Time (ms)')
axes[3].set_ylabel('Amplitude')
axes[3].legend()
axes[3].grid(True, alpha=0.3)

# Plot 4: Reconstruction
axes[4].plot(t * 1000, x_original, 'b-', alpha=0.3, linewidth=2, label='Original')
axes[4].plot(t * 1000, x_reconstructed, 'r-', linewidth=1.5, label='Reconstructed')
axes[4].set_title(f'Stage 4: Reconstruction (Cubic Spline) | Total RMS Error = {rms_total:.6f}', fontsize=13)
axes[4].set_xlabel('Time (ms)')
axes[4].set_ylabel('Amplitude')
axes[4].legend()
axes[4].grid(True, alpha=0.3)

# Plot 5: Error breakdown
axes[5].plot(t * 1000, filter_error, 'g-', alpha=0.7, label=f'Filter error (RMS={rms_filter:.4f})')
axes[5].plot(t * 1000, total_error, 'r-', alpha=0.5, label=f'Total error (RMS={rms_total:.4f})')
axes[5].set_title('Stage 5: Error Analysis', fontsize=13)
axes[5].set_xlabel('Time (ms)')
axes[5].set_ylabel('Error')
axes[5].legend()
axes[5].grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

# ============================================================
# Spectrum comparison
# ============================================================
def spectrum(x, fs):
    N = len(x)
    X = np.fft.fft(x)
    f = np.fft.fftfreq(N, 1/fs)
    mag = np.abs(X) / N * 2
    pos = f >= 0
    return f[pos], mag[pos]

f_orig, m_orig = spectrum(x_original, fs_continuous)
f_recon, m_recon = spectrum(x_reconstructed, fs_continuous)

fig, axes = plt.subplots(2, 1, figsize=(14, 8))

axes[0].plot(f_orig, m_orig, 'b-', label='Original')
axes[0].set_title('Original Signal Spectrum')
axes[0].set_xlabel('Frequency (Hz)')
axes[0].set_ylabel('Magnitude')
axes[0].set_xlim(0, 10000)
axes[0].axvline(x=f_nyquist, color='r', linestyle='--', label=f'Nyquist = {f_nyquist} Hz')
axes[0].legend()
axes[0].grid(True, alpha=0.3)

axes[1].plot(f_recon, m_recon, 'r-', label='Reconstructed')
axes[1].set_title('Reconstructed Signal Spectrum')
axes[1].set_xlabel('Frequency (Hz)')
axes[1].set_ylabel('Magnitude')
axes[1].set_xlim(0, 10000)
axes[1].axvline(x=f_nyquist, color='r', linestyle='--', label=f'Nyquist = {f_nyquist} Hz')
axes[1].legend()
axes[1].grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

# ============================================================
# Final Summary
# ============================================================
print("\n" + "=" * 60)
print("PIPELINE SUMMARY")
print("=" * 60)
print(f"""
┌─────────────────────────────────────────────────────────┐
│ Original Signal:                                         │
│   Frequencies: {frequencies}          │
│   Max frequency: {max(frequencies)} Hz                           │
│                                                          │
│ Anti-Aliasing Filter:                                    │
│   Type: Butterworth, Order {order}                            │
│   Cutoff: {f_nyquist} Hz                                      │
│   Removed: {[f for f in frequencies if f >= f_nyquist]} Hz                      │
│   Error contribution (RMS): {rms_filter:.6f}                │
│                                                          │
│ Sampling:                                                │
│   Rate: {fs_target} Hz                                        │
│   Samples: {N_samples}                                          │
│                                                          │
│ Quantization:                                            │
│   Bits: {num_bits}                                              │
│   Levels: {num_levels}                                          │
│   SQNR: {SQNR:.2f} dB                                      │
│   Error contribution (RMS): {rms_quant:.6f}                │
│                                                          │
│ Reconstruction:                                          │
│   Method: Cubic Spline                                   │
│   Error contribution (RMS): {rms_recon:.6f}                │
│                                                          │
│ TOTAL RECONSTRUCTION ERROR (RMS): {rms_total:.6f}          │
└─────────────────────────────────────────────────────────┘
""")