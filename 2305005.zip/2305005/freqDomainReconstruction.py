import numpy as np
import matplotlib.pyplot as plt

# ==================================================
# Original signal and its spectrum
# ==================================================
f_signal = 5   # Hz
fs = 40        # Sampling frequency
Ts = 1 / fs
T = 1          # Duration
N_cont = 10000

# Continuous signal (simulated)
t_cont = np.linspace(0, T, N_cont, endpoint=False)
x_cont = np.sin(2 * np.pi * f_signal * t_cont)

# Sampled signal
t_s = np.arange(0, T, Ts)
x_s = np.sin(2 * np.pi * f_signal * t_s)
N_samples = len(x_s)

# ==================================================
# KEY CONCEPT: Sampling in time = Periodic copies in frequency
# ==================================================
# When you sample at fs, the spectrum repeats every fs Hz
# Original spectrum: peak at ±5 Hz
# After sampling: peaks at ±5, ±5+40, ±5+80, ±5-40, ±5-80, etc.
# In other words: peaks at 5, 35, 45, 75, 85, ... Hz
#                 and at -5, -35, -45, -75, -85, ... Hz

# Compute spectrum of sampled signal
X_s = np.fft.fft(x_s)
freqs_s = np.fft.fftfreq(N_samples, Ts)
mag_s = np.abs(X_s) / N_samples * 2

# For visualization: compute many spectral copies manually
# The DTFT of the sampled signal has copies centered at k×fs
def plot_spectral_copies(ax, f_signal, fs, num_copies=3):
    """
    Show how sampling creates spectral copies.
    
    In frequency domain, sampling = convolution with impulse train
    This creates copies of the spectrum at every multiple of fs.
    """
    freq_range = np.arange(-fs * num_copies, fs * num_copies, 0.01)
    spectrum = np.zeros(len(freq_range))
    
    for k in range(-num_copies, num_copies + 1):
        # Copy centered at k × fs
        center = k * fs
        
        # Original spectrum has impulses at ±f_signal
        # So copies appear at center ± f_signal
        for sign in [1, -1]:
            f_copy = center + sign * f_signal
            # Find closest index
            idx = np.argmin(np.abs(freq_range - f_copy))
            spectrum[idx] = 0.5  # Amplitude of each spectral line
            
            # Draw arrow for this copy
            color = 'blue' if k == 0 else 'red'
            alpha = 1.0 if k == 0 else 0.4
            ax.annotate('', xy=(f_copy, 0.5), xytext=(f_copy, 0),
                        arrowprops=dict(arrowstyle='->', color=color, 
                                       lw=2, alpha=alpha))
            if abs(k) <= 1:  # Label only nearby copies
                ax.text(f_copy, 0.55, f'{f_copy}Hz', ha='center', fontsize=8,
                        color=color, alpha=alpha)
    
    return freq_range, spectrum

# ==================================================
# PLOT
# ==================================================
fig, axes = plt.subplots(4, 1, figsize=(14, 16))

# --- Plot 1: Original spectrum ---
axes[0].set_title('Step 1: Original Signal Spectrum', fontsize=13)
axes[0].annotate('', xy=(f_signal, 0.5), xytext=(f_signal, 0),
                arrowprops=dict(arrowstyle='->', color='blue', lw=3))
axes[0].annotate('', xy=(-f_signal, 0.5), xytext=(-f_signal, 0),
                arrowprops=dict(arrowstyle='->', color='blue', lw=3))
axes[0].text(f_signal, 0.55, f'{f_signal} Hz', ha='center', fontsize=11, color='blue')
axes[0].text(-f_signal, 0.55, f'-{f_signal} Hz', ha='center', fontsize=11, color='blue')
axes[0].axhline(y=0, color='k', linewidth=0.5)
axes[0].set_xlim(-100, 100)
axes[0].set_ylim(-0.1, 0.8)
axes[0].set_xlabel('Frequency (Hz)')
axes[0].set_ylabel('Magnitude')
axes[0].grid(True, alpha=0.3)

# --- Plot 2: After sampling (spectral copies appear) ---
axes[1].set_title(f'Step 2: After Sampling at fs={fs} Hz (Spectrum gets replicated every {fs} Hz)', fontsize=13)
plot_spectral_copies(axes[1], f_signal, fs, num_copies=3)
axes[1].axhline(y=0, color='k', linewidth=0.5)
axes[1].set_xlim(-100, 100)
axes[1].set_ylim(-0.1, 0.8)
axes[1].set_xlabel('Frequency (Hz)')
axes[1].set_ylabel('Magnitude')
axes[1].grid(True, alpha=0.3)

# Mark Nyquist boundaries
for boundary in [-fs/2, fs/2]:
    axes[1].axvline(x=boundary, color='green', linestyle='--', linewidth=2, alpha=0.7)
axes[1].text(fs/2 + 1, 0.7, f'Nyquist = ±{fs/2} Hz', fontsize=10, color='green')

# --- Plot 3: Apply ideal low-pass filter ---
axes[2].set_title(f'Step 3: Apply Ideal Low-Pass Filter (cutoff = fs/2 = {fs/2} Hz)', fontsize=13)
plot_spectral_copies(axes[2], f_signal, fs, num_copies=3)
# Draw the filter
filter_freqs = [-fs/2, -fs/2, fs/2, fs/2]
filter_response = [0, 0.7, 0.7, 0]
axes[2].fill_between([-fs/2, fs/2], 0, 0.7, alpha=0.15, color='green', label='LPF passband')
axes[2].plot([-100, -fs/2, -fs/2, fs/2, fs/2, 100], 
              [0, 0, 0.7, 0.7, 0, 0], 'g-', linewidth=3, label='Ideal LPF')
axes[2].axhline(y=0, color='k', linewidth=0.5)
axes[2].set_xlim(-100, 100)
axes[2].set_ylim(-0.1, 0.8)
axes[2].set_xlabel('Frequency (Hz)')
axes[2].set_ylabel('Magnitude')
axes[2].legend(fontsize=10)
axes[2].grid(True, alpha=0.3)

# --- Plot 4: Result after filtering = reconstructed signal ---
axes[3].set_title('Step 4: After Low-Pass Filtering = Reconstructed Spectrum (= Original!)', fontsize=13)
axes[3].annotate('', xy=(f_signal, 0.5), xytext=(f_signal, 0),
                arrowprops=dict(arrowstyle='->', color='blue', lw=3))
axes[3].annotate('', xy=(-f_signal, 0.5), xytext=(-f_signal, 0),
                arrowprops=dict(arrowstyle='->', color='blue', lw=3))
axes[3].text(f_signal, 0.55, f'{f_signal} Hz ✓', ha='center', fontsize=11, color='blue')
axes[3].text(-f_signal, 0.55, f'-{f_signal} Hz ✓', ha='center', fontsize=11, color='blue')
axes[3].axhline(y=0, color='k', linewidth=0.5)
axes[3].set_xlim(-100, 100)
axes[3].set_ylim(-0.1, 0.8)
axes[3].set_xlabel('Frequency (Hz)')
axes[3].set_ylabel('Magnitude')
axes[3].grid(True, alpha=0.3)
axes[3].text(0, 0.7, '🎉 Original spectrum recovered!', ha='center', 
              fontsize=14, color='green', fontweight='bold')

plt.tight_layout()
plt.show()

# ==================================================
# Demonstrate numerically: LPF reconstruction
# ==================================================
print("\n" + "=" * 60)
print("FREQUENCY DOMAIN RECONSTRUCTION SUMMARY")
print("=" * 60)
print(f"\nOriginal signal frequency: {f_signal} Hz")
print(f"Sampling frequency: {fs} Hz")
print(f"Nyquist frequency: {fs/2} Hz")
print(f"\nAfter sampling, spectral copies appear at:")
for k in range(-2, 3):
    f_plus = k * fs + f_signal
    f_minus = k * fs - f_signal
    in_band = "← IN PASSBAND" if abs(f_plus) <= fs/2 or abs(f_minus) <= fs/2 else ""
    print(f"  k={k:+d}: frequencies at {f_plus:+.0f} Hz and {f_minus:+.0f} Hz {in_band}")
print(f"\nLow-pass filter keeps only frequencies in [-{fs/2}, +{fs/2}] Hz")
print(f"Result: Only ±{f_signal} Hz survives → Original signal recovered! ✓")