import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline

# ==================================================
# STEP 1: Create the original "continuous" signal
# ==================================================
f1 = 3    # Hz
f2 = 7    # Hz
A1 = 1.0
A2 = 0.5

# Simulate continuous with very fine time steps
t_cont = np.arange(0, 1, 0.00001)  # 100,000 points per second
x_cont = A1 * np.sin(2 * np.pi * f1 * t_cont) + A2 * np.sin(2 * np.pi * f2 * t_cont)

# ==================================================
# STEP 2: Sample the signal
# ==================================================
fs = 30                           # Sampling frequency
Ts = 1 / fs                       # Sampling period
t_samples = np.arange(0, 1, Ts)   # Sample time points: 0, 1/30, 2/30, ...
x_samples = A1 * np.sin(2 * np.pi * f1 * t_samples) + A2 * np.sin(2 * np.pi * f2 * t_samples)

print(f"Signal: sin(2π×{f1}t) + 0.5×sin(2π×{f2}t)")
print(f"f_max = {f2} Hz")
print(f"Nyquist rate = {2 * f2} Hz")
print(f"Sampling rate = {fs} Hz  ✓ (> Nyquist rate)")
print(f"Number of samples = {len(x_samples)}")

# ==================================================
# STEP 3: Reconstruction Method 1 — Zero-Order Hold
# ==================================================
def zero_order_hold(t_recon, t_samp, x_samp):
    """
    For each reconstruction time point, find the most recent 
    sample and use its value.
    
    Logic:
    - np.searchsorted finds where t would be inserted in t_samp
    - Subtract 1 to get the sample AT or BEFORE t
    - Clip to valid index range
    """
    x_recon = np.zeros(len(t_recon))
    for i in range(len(t_recon)):
        # Find index of latest sample before t_recon[i]
        idx = np.searchsorted(t_samp, t_recon[i], side='right') - 1
        # side='right' means: if t_recon[i] equals a sample time,
        # searchsorted returns the index AFTER it, so -1 gives us that sample
        idx = np.clip(idx, 0, len(x_samp) - 1)  # Safety: don't go out of bounds
        x_recon[i] = x_samp[idx]
    return x_recon

x_zoh = zero_order_hold(t_cont, t_samples, x_samples)

# ==================================================
# STEP 4: Reconstruction Method 2 — First-Order Hold
# ==================================================
def first_order_hold(t_recon, t_samp, x_samp):
    """
    Linear interpolation between consecutive samples.
    
    For t between t_samp[n] and t_samp[n+1]:
        x(t) = x[n] + (x[n+1] - x[n]) * (t - t[n]) / (t[n+1] - t[n])
    
    np.interp does exactly this!
    """
    return np.interp(t_recon, t_samp, x_samp)
    # np.interp(x_new, x_known, y_known)
    # x_new   = times where we want values
    # x_known = sample times (must be sorted — ours is)
    # y_known = sample values

x_foh = first_order_hold(t_cont, t_samples, x_samples)

# ==================================================
# STEP 5: Reconstruction Method 3 — Cubic Spline
# ==================================================
def cubic_spline_reconstruction(t_recon, t_samp, x_samp):
    """
    Fit a cubic polynomial between each pair of consecutive samples.
    
    CubicSpline ensures:
    1. Curve passes through all sample points
    2. First derivative is continuous (smooth)
    3. Second derivative is continuous (very smooth)
    """
    # Create the cubic spline interpolator
    cs = CubicSpline(t_samp, x_samp)
    # cs is now a function that can evaluate the spline at any point
    
    return cs(t_recon)  # Evaluate at all reconstruction points

x_cubic = cubic_spline_reconstruction(t_cont, t_samples, x_samples)

# ==================================================
# STEP 6: Reconstruction Method 4 — Sinc Interpolation
# ==================================================
def sinc_interpolation(t_recon, t_samp, x_samp, Ts):
    """
    Shannon's reconstruction formula:
    x(t) = Σ x[n] × sinc((t - n×Ts) / Ts)
    
    Each sample contributes a shifted and scaled sinc function.
    We sum contributions from ALL samples for each reconstruction point.
    
    np.sinc(u) computes sin(π×u) / (π×u)
    """
    x_recon = np.zeros(len(t_recon))
    
    for n in range(len(t_samp)):
        # Argument of sinc: (t - nTs) / Ts
        # When t = nTs: argument = 0, sinc(0) = 1 → full contribution
        # When t = mTs (m≠n): argument = integer, sinc = 0 → no contribution
        sinc_arg = (t_recon - t_samp[n]) / Ts
        x_recon += x_samp[n] * np.sinc(sinc_arg)
    
    return x_recon

x_sinc = sinc_interpolation(t_cont, t_samples, x_samples, Ts)

# ==================================================
# STEP 7: Compute Errors
# ==================================================
def rms_error(original, reconstructed):
    """Root Mean Square Error"""
    return np.sqrt(np.mean((original - reconstructed) ** 2))

def max_error(original, reconstructed):
    """Maximum Absolute Error"""
    return np.max(np.abs(original - reconstructed))

errors = {
    'Zero-Order Hold': {
        'RMS': rms_error(x_cont, x_zoh),
        'Max': max_error(x_cont, x_zoh)
    },
    'First-Order Hold': {
        'RMS': rms_error(x_cont, x_foh),
        'Max': max_error(x_cont, x_foh)
    },
    'Cubic Spline': {
        'RMS': rms_error(x_cont, x_cubic),
        'Max': max_error(x_cont, x_cubic)
    },
    'Sinc Interpolation': {
        'RMS': rms_error(x_cont, x_sinc),
        'Max': max_error(x_cont, x_sinc)
    }
}

# ==================================================
# STEP 8: Plot Everything
# ==================================================
methods = [
    ('Zero-Order Hold (ZOH)', x_zoh, 'red'),
    ('First-Order Hold (FOH)', x_foh, 'green'),
    ('Cubic Spline', x_cubic, 'orange'),
    ('Sinc Interpolation (Ideal)', x_sinc, 'purple')
]

fig, axes = plt.subplots(4, 2, figsize=(16, 16))

for i, (name, x_recon, color) in enumerate(methods):
    err = x_cont - x_recon
    
    # Left column: Signal comparison
    axes[i][0].plot(t_cont, x_cont, 'b-', linewidth=2, alpha=0.4, label='Original')
    axes[i][0].plot(t_cont, x_recon, color=color, linewidth=1.5, label=name)
    axes[i][0].stem(t_samples, x_samples, linefmt='k-', markerfmt='ko', 
                     basefmt='k-', label='Samples')
    axes[i][0].set_title(f'{name}')
    axes[i][0].set_xlabel('Time (s)')
    axes[i][0].set_ylabel('Amplitude')
    axes[i][0].legend(fontsize=8, loc='upper right')
    axes[i][0].grid(True, alpha=0.3)
    axes[i][0].set_xlim(0, 0.5)  # Show first half for clarity
    
    # Right column: Error
    axes[i][1].plot(t_cont, err, color=color, linewidth=1)
    axes[i][1].set_title(f'Error | RMS={errors[name]["RMS"]:.6f} | Max={errors[name]["Max"]:.6f}')
    axes[i][1].set_xlabel('Time (s)')
    axes[i][1].set_ylabel('Error')
    axes[i][1].grid(True, alpha=0.3)
    axes[i][1].set_xlim(0, 0.5)

plt.tight_layout()
plt.show()

# ==================================================
# STEP 9: Print Summary
# ==================================================
print("\n" + "=" * 65)
print(f"{'Method':<30} {'RMS Error':>15} {'Max Error':>15}")
print("=" * 65)
for name, err in errors.items():
    print(f"{name:<30} {err['RMS']:>15.8f} {err['Max']:>15.8f}")
print("=" * 65)
print("\n🏆 Best method: Sinc Interpolation (theoretically perfect)")