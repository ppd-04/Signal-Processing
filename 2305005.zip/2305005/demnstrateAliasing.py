import numpy as np
import matplotlib.pyplot as plt

f_signal = 10

tcont = np.arange(0, 1, .001)
xcont = np.sin(2*np.pi*f_signal*tcont)

samplingRates = [25, 15, 8]
fig, axes = plt.subplots(3, 1, figsize=(12, 10))
for i, fs in enumerate(samplingRates):
    Ts = 1/fs
    tsampled= np.arange(0, 1, Ts)
    xSampled= np.sin(2*np.pi*f_signal*tsampled)

    f_alias = abs(f_signal-round(f_signal-fs)*fs)
    x_alias = np.sin(2*np.pi*f_alias*tcont)

    axes[i].plot(tcont, xcont, 'b-', alpha=0.5, label=f'Original: {f_signal} Hz')
    axes[i].stem(tsampled, xSampled, linefmt='r-', markerfmt='ro', basefmt='k-', label=f'Samples (fs={fs} Hz)')
    if f_alias != f_signal:  # If aliasing occurred
        axes[i].plot(tcont, x_alias, 'g--', linewidth=2, label=f'Aliased signal: {f_alias} Hz')
    
    # Check Nyquist condition
    nyquist = 2 * f_signal
    status = "✓ No aliasing" if fs >= nyquist else f"✗ Aliasing! (need fs ≥ {nyquist} Hz)"
    axes[i].set_title(f'fs = {fs} Hz | Nyquist rate = {nyquist} Hz | {status}')
    axes[i].legend(loc='upper right')
    axes[i].grid(True)
    axes[i].set_xlabel('Time (s)')
    axes[i].set_ylabel('Amplitude')

plt.tight_layout()
plt.show()
