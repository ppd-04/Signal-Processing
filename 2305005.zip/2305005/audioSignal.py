import numpy as np
import matplotlib.pyplot as plt

# ---- Musical note frequencies (A Major chord) ----
notes = {
    'A4': 440.0,
    'C#5': 554.37,
    'E5': 659.26,
    # Adding harmonics (overtones) - real instruments have these
    'A4_2nd': 880.0,
    'A4_3rd': 1320.0,
    'A4_4th': 1760.0,
    'C#5_2nd': 1108.74,
    'E5_2nd': 1318.51,
    'A4_5th': 2200.0,
    'A4_6th': 2640.0,
    'High_overtone_1': 3500.0,
    'High_overtone_2': 5000.0,
}

# ---- Generate "continuous" signal ----
fs_continuous = 100000  # 100 kHz (simulated continuous)
T = 0.01  # 10 ms for visualization
t = np.arange(0, T, 1/fs_continuous)

x = np.zeros(len(t))
for name, freq in notes.items():
    amp = 1.0 / (1 + freq/440)  # Higher frequencies have lower amplitude (natural decay)
    x += amp * np.sin(2 * np.pi * freq * t)

# ---- Sample at two rates ----
fs_cd = 44100       # CD quality
fs_phone = 8000     # Telephone quality

# Create sampled versions
t_cd = np.arange(0, T, 1/fs_cd)
x_cd = np.zeros(len(t_cd))
for name, freq in notes.items():
    amp = 1.0 / (1 + freq/440)
    x_cd += amp * np.sin(2 * np.pi * freq * t_cd)

t_phone = np.arange(0, T, 1/fs_phone)
x_phone = np.zeros(len(t_phone))
for name, freq in notes.items():
    amp = 1.0 / (1 + freq/440)
    x_phone += amp * np.sin(2 * np.pi * freq * t_phone)

# ---- Compute spectra ----
# Use longer signal for better frequency resolution
T_long = 0.1
t_long_cd = np.arange(0, T_long, 1/fs_cd)
t_long_phone = np.arange(0, T_long, 1/fs_phone)
t_long_cont = np.arange(0, T_long, 1/fs_continuous)

x_long_cont = sum(
    (1.0/(1+f/440)) * np.sin(2*np.pi*f*t_long_cont)
    for f in notes.values()
)
x_long_cd = sum(
    (1.0/(1+f/440)) * np.sin(2*np.pi*f*t_long_cd)
    for f in notes.values()
)
x_long_phone = sum(
    (1.0/(1+f/440)) * np.sin(2*np.pi*f*t_long_phone)
    for f in notes.values()
)

def spectrum(x, fs):
    N = len(x)
    X = np.fft.fft(x)
    f = np.fft.fftfreq(N, 1/fs)
    mag = np.abs(X) / N * 2
    pos = f >= 0
    return f[pos], mag[pos]

f_cont, m_cont = spectrum(x_long_cont, fs_continuous)
f_cd, m_cd = spectrum(x_long_cd, fs_cd)
f_phone, m_phone = spectrum(x_long_phone, fs_phone)

# ---- Analysis: which frequencies are preserved? ----
nyquist_cd = fs_cd / 2      # 22050 Hz
nyquist_phone = fs_phone / 2  # 4000 Hz

preserved_cd = {k: v for k, v in notes.items() if v < nyquist_cd}
lost_cd = {k: v for k, v in notes.items() if v >= nyquist_cd}
preserved_phone = {k: v for k, v in notes.items() if v < nyquist_phone}
lost_phone = {k: v for k, v in notes.items() if v >= nyquist_phone}

# ---- Plot ----
fig, axes = plt.subplots(3, 1, figsize=(14, 12))

# Original
axes[0].plot(f_cont, m_cont, 'b-', alpha=0.7)
axes[0].set_title(f'Original Signal Spectrum (all {len(notes)} components)')
axes[0].set_xlabel('Frequency (Hz)')
axes[0].set_ylabel('Magnitude')
axes[0].set_xlim(0, 6000)
for name, freq in notes.items():
    axes[0].axvline(x=freq, color='gray', alpha=0.3, linestyle='--')
axes[0].grid(True)

# CD Quality
axes[1].plot(f_cd, m_cd, 'g-', alpha=0.7)
axes[1].axvline(x=nyquist_cd, color='r', linestyle='--', linewidth=2, label=f'Nyquist = {nyquist_cd} Hz')
axes[1].set_title(f'CD Quality (fs={fs_cd} Hz) — Preserves {len(preserved_cd)}/{len(notes)} components')
axes[1].set_xlabel('Frequency (Hz)')
axes[1].set_ylabel('Magnitude')
axes[1].set_xlim(0, 6000)
axes[1].legend()
axes[1].grid(True)

# Telephone Quality
axes[2].plot(f_phone, m_phone, 'r-', alpha=0.7)
axes[2].axvline(x=nyquist_phone, color='r', linestyle='--', linewidth=2, label=f'Nyquist = {nyquist_phone} Hz')
axes[2].set_title(f'Telephone Quality (fs={fs_phone} Hz) — Preserves {len(preserved_phone)}/{len(notes)} components')
axes[2].set_xlabel('Frequency (Hz)')
axes[2].set_ylabel('Magnitude')
axes[2].set_xlim(0, 6000)
axes[2].legend()
axes[2].grid(True)

plt.tight_layout()
plt.show()

# ---- Print analysis ----
print("\n" + "="*60)
print("CD Quality (44100 Hz):")
print(f"  Nyquist frequency: {nyquist_cd} Hz")
print(f"  Preserved: {list(preserved_cd.keys())}")
print(f"  Lost (aliased): {list(lost_cd.keys())}")

print(f"\nTelephone Quality (8000 Hz):")
print(f"  Nyquist frequency: {nyquist_phone} Hz")
print(f"  Preserved: {list(preserved_phone.keys())}")
print(f"  Lost (aliased): {list(lost_phone.keys())}")