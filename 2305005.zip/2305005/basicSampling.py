import numpy as np
import matplotlib.pyplot as plt

# ---- Step 1: Define the "continuous" signal ----
# We simulate continuous by using a VERY high sample rate
f1 = 5          # First frequency component: 5 Hz
f2 = 12         # Second frequency component: 12 Hz
t_continuous = np.arange(0, 1, 0.0001)  
# 0 to 1 second, step=0.0001s → acts like continuous (10000 points/sec)
 
x_continuous = np.sin(2 * np.pi * f1 * t_continuous) + np.sin(2 * np.pi * f2 * t_continuous)

# ---- Step 2: Sample the signal at fs = 50 Hz ----
fs = 50                            # Sampling frequency
Ts = 1 / fs                        # Sampling period = 0.02 seconds
t_sampled = np.arange(0, 1, Ts)    # Sample time points: 0, 0.02, 0.04, ...
x_sampled = np.sin(2 * np.pi * f1 * t_sampled) + np.sin(2 * np.pi * f2 * t_sampled)

# ---- Step 3: Plot ----
plt.figure(figsize=(12, 5))
plt.plot(t_continuous, x_continuous, 'b-', label='Continuous Signal', linewidth=1)
plt.stem(t_sampled, x_sampled, linefmt='r-', markerfmt='ro', basefmt='k-', label=f'Sampled at fs={fs} Hz')
plt.xlabel('Time (seconds)')
plt.ylabel('Amplitude')
plt.title('Sampling of x(t) = sin(2π·5t) + sin(2π·12t)')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()