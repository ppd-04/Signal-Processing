import numpy as np
import matplotlib.pyplot as plt

# ---- Generate signal ----
fs = 1000
T = 0.01  # 10 ms (so we can see the waveform clearly)
t = np.arange(0, T, 1/fs)
f_signal = 100  # 100 Hz sine wave
x = np.sin(2 * np.pi * f_signal * t)  # Range: [-1, 1]

# ---- Quantization function ----
def quantize(signal, num_bits, x_min=-1, x_max=1):
    """
    Quantize a signal to a given number of bits.
    
    Parameters:
    - signal: input signal array
    - num_bits: number of bits for quantization
    - x_min, x_max: signal range
    
    Returns:
    - quantized signal
    - quantization step size
    """
    num_levels = 2 ** num_bits           # e.g., 3 bits → 8 levels
    delta = (x_max - x_min) / num_levels  # Step size (quantization interval)
    
    # Quantize: 
    # 1. Normalize to [0, num_levels]
    # 2. Round to nearest integer (floor)
    # 3. Convert back to signal range
    
    x_normalized = (signal - x_min) / delta
    x_quantized_index = np.floor(x_normalized).astype(int)
    x_quantized_index = np.clip(x_quantized_index, 0, num_levels - 1)  # Clamp to valid range
    x_quantized = x_min + x_quantized_index * delta + delta / 2  # Center of each level
    
    return x_quantized, delta

# ---- Test with different bit depths ----
bit_depths = [3, 4, 6, 8]
fig, axes = plt.subplots(len(bit_depths), 1, figsize=(12, 12))

results = []

for i, B in enumerate(bit_depths):
    x_q, delta = quantize(x, B)
    
    # Quantization error
    error = x - x_q
    
    # SQNR calculation
    signal_power = np.mean(x ** 2)
    noise_power = np.mean(error ** 2)
    SQNR_actual = 10 * np.log10(signal_power / noise_power)  # in dB
    
    # Theoretical SQNR
    SQNR_theory = 6.02 * B + 1.76  # dB
    
    results.append({
        'bits': B,
        'levels': 2**B,
        'delta': delta,
        'SQNR_actual': SQNR_actual,
        'SQNR_theory': SQNR_theory
    })
    
    # Plot
    axes[i].plot(t * 1000, x, 'b-', linewidth=2, label='Original', alpha=0.7)
    axes[i].step(t * 1000, x_q, 'r-', linewidth=1.5, label=f'Quantized ({B} bits, {2**B} levels)')
    axes[i].set_title(f'B = {B} bits | Δ = {delta:.4f} | SQNR = {SQNR_actual:.2f} dB (Theory: {SQNR_theory:.2f} dB)')
    axes[i].set_xlabel('Time (ms)')
    axes[i].set_ylabel('Amplitude')
    axes[i].legend(loc='upper right')
    axes[i].grid(True)

plt.tight_layout()
plt.show()

# ---- Print summary table ----
print(f"\n{'Bits':>5} {'Levels':>7} {'Step(Δ)':>10} {'SQNR(actual)':>14} {'SQNR(theory)':>14} {'Difference':>12}")
print("-" * 65)
for r in results:
    diff = r['SQNR_actual'] - r['SQNR_theory']
    print(f"{r['bits']:>5} {r['levels']:>7} {r['delta']:>10.4f} {r['SQNR_actual']:>12.2f} dB {r['SQNR_theory']:>12.2f} dB {diff:>10.2f} dB")