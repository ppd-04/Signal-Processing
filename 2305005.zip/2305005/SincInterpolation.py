import numpy as np
import matplotlib.pyplot as plt

# ---- Original "continuous" signal ----
f_signal = 5  # Hz
t_continuous = np.arange(0, 1, 0.0001)
x_continuous = np.sin(2 * np.pi * f_signal * t_continuous)

# ---- Sample the signal ----
fs = 20  # Sampling frequency (Nyquist rate = 10 Hz, so fs=20 is adequate)
Ts = 1 / fs
n_samples = np.arange(0, 1, Ts)  # Sample times: 0, 0.05, 0.1, ..., 0.95
x_samples = np.sin(2 * np.pi * f_signal * n_samples)

# ---- Reconstruct using sinc interpolation ----
# Shannon's reconstruction formula:
# x(t) = Σ x[n] * sinc((t - nTs) / Ts)
# where sinc(x) = sin(πx) / (πx)  [numpy's definition of sinc]

def reconstruct_sinc(t_recon, sample_times, sample_values, Ts):
    """
    Reconstruct a signal using Whittaker-Shannon interpolation.
    
    Parameters:
    - t_recon: time points where we want to reconstruct
    - sample_times: times at which samples were taken
    - sample_values: the sample values
    - Ts: sampling period
    
    Returns:
    - reconstructed signal values at t_recon points
    """
    x_recon = np.zeros(len(t_recon))
    
    for n in range(len(sample_times)):
        # Each sample contributes a scaled sinc function
        # np.sinc(x) computes sin(πx)/(πx), which is what we need
        x_recon += sample_values[n] * np.sinc((t_recon - sample_times[n]) / Ts)
    
    return x_recon

x_reconstructed = reconstruct_sinc(t_continuous, n_samples, x_samples, Ts)

# ---- Compute reconstruction error ----
error = x_continuous - x_reconstructed

# ---- Plot ----
fig, axes = plt.subplots(2, 1, figsize=(12, 8))

axes[0].plot(t_continuous, x_continuous, 'b-', linewidth=2, label='Original Signal')
axes[0].stem(n_samples, x_samples, linefmt='r-', markerfmt='ro', basefmt='k-', label='Samples')
axes[0].plot(t_continuous, x_reconstructed, 'g--', linewidth=2, label='Reconstructed (sinc)')
axes[0].set_title(f'Signal Reconstruction via Sinc Interpolation (fs = {fs} Hz)')
axes[0].set_xlabel('Time (s)')
axes[0].set_ylabel('Amplitude')
axes[0].legend()
axes[0].grid(True)

axes[1].plot(t_continuous, error, 'm-')
axes[1].set_title(f'Reconstruction Error (Max error = {np.max(np.abs(error)):.6f})')
axes[1].set_xlabel('Time (s)')
axes[1].set_ylabel('Error')
axes[1].grid(True)

plt.tight_layout()
plt.show()