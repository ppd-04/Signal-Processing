import numpy as np 
import matplotlib.pyplot as plt

f = 50
fs= 200
duration = 0.2

t = np.arange(0, duration, 1/fs)
x = np.sin(2*np.pi*fs*t)

plt.figure()
plt.stem(t, x)
plt.xlabel("time")
plt.ylabel("Amp")
plt.title("hi")
plt.show()

x = np.fft.fft(x)

freq= np.fft.fftfreq(len(x), 1/fs)
plt.figure()
plt.plot(freq, np.abs(x))
plt.xlabel("Frequency (Hz)")
plt.ylabel("Magnitude")
plt.title("Frequency Spectrum")
plt.show()