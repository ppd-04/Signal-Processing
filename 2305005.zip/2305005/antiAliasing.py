import numpy as np
import matplotlib.pyplot as plt
from scipy import signal as sig

# ---- Create a wideband signal (0 to 200 Hz) ----
fs_high = 5000  # Simulate "continuous" with high rate
T = 0.5         # Duration
t = np.arange(0, T, 1/fs_high)

# Signal with multiple frequency components
freqs = [30, 60, 100, 150, 180]  # Hz
amps = [1.0, 0.8, 0.6, 0.5, 0.4]

x = np.zeros(len(t))
for f, a in zip(freqs, amps):
    x += a * np.sin(2 * np.pi * f * t)

# ---- Design Anti-Aliasing Filter ----
fs_target = 250        # Target sampling rate
f_nyquist = fs_target / 2  # = 125 Hz (maximum frequency we can represent)

# Design a Butterworth low-pass filter
filter_order = 8  # Higher order = sharper cutoff
# Wn is normalized frequency: cutoff / (fs_high/2)
Wn = f_nyquist / (fs_high / 2)
b, a = sig.butter(filter_order, Wn, btype='low')

# Apply filter
x_filtered = sig.filtfilt(b, a, x)
# filtfilt applies filter forward and backward → zero phase distortion

# ---- Sample both signals ----
downsample_factor = fs_high // fs_target  # = 20
t_sampled = t[::downsample_factor]
x_sampled_no_filter = x[::downsample_factor]      # Sampling WITHOUT anti-aliasing
x_sampled_filtered = x_filtered[::downsample_factor]  # Sampling WITH anti-aliasing

# ---- Compute spectra ----
def spectrum(x, fs):
    N = len(x)
    X = np.fft.fft(x)
    f = np.fft.fftfreq(N, 1/fs)
    mag = np.abs(X) / N * 2
    pos = f >= 0
    return f[pos], mag[pos]

freq_orig, mag_orig = spectrum(x, fs_high)
freq_filt, mag_filt = spectrum(x_filtered, fs_high)
freq_samp_nf, mag_samp_nf = spectrum(x_sampled_no_filter, fs_target)
freq_samp_f, mag_samp_f = spectrum(x_sampled_filtered, fs_target)

# ---- Plot ----
fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# Original spectrum
axes[0][0].plot(freq_orig, mag_orig, 'b-')
axes[0][0].axvline(x=f_nyquist, color='r', linestyle='--', label=f'Nyquist = {f_nyquist} Hz')
axes[0][0].set_title('Original Signal Spectrum')
axes[0][0].set_xlabel('Frequency (Hz)')
axes[0][0].set_xlim(0, 250)
axes[0][0].legend()
axes[0][0].grid(True)

# After anti-aliasing filter
axes[0][1].plot(freq_filt, mag_filt, 'g-')
axes[0][1].axvline(x=f_nyquist, color='r', linestyle='--', label=f'Nyquist = {f_nyquist} Hz')
axes[0][1].set_title('After Anti-Aliasing Filter')
axes[0][1].set_xlabel('Frequency (Hz)')
axes[0][1].set_xlim(0, 250)
axes[0][1].legend()
axes[0][1].grid(True)

# Sampled WITHOUT filter
axes[1][0].stem(freq_samp_nf, mag_samp_nf, linefmt='r-', markerfmt='r.', basefmt='k-')
axes[1][0].set_title(f'Sampled WITHOUT Filter (fs={fs_target} Hz) — ALIASED!')
axes[1][0].set_xlabel('Frequency (Hz)')
axes[1][0].set_xlim(0, fs_target/2)
axes[1][0].grid(True)

# Sampled WITH filter
axes[1][1].stem(freq_samp_f, mag_samp_f, linefmt='g-', markerfmt='g.', basefmt='k-')
axes[1][1].set_title(f'Sampled WITH Filter (fs={fs_target} Hz) — Clean!')
axes[1][1].set_xlabel('Frequency (Hz)')
axes[1][1].set_xlim(0, fs_target/2)
axes[1][1].grid(True)

plt.tight_layout()
plt.show()

print(f"Signal frequencies: {freqs} Hz")
print(f"Target fs = {fs_target} Hz, Nyquist = {f_nyquist} Hz")
print(f"Frequencies BELOW Nyquist (kept): {[f for f in freqs if f < f_nyquist]}")
print(f"Frequencies ABOVE Nyquist (removed by filter): {[f for f in freqs if f >= f_nyquist]}")