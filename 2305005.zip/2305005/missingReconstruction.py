import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline

np.random.seed(42)  # For reproducible results

# ==================================================
# Generate signal and sample
# ==================================================
f = 5
fs = 50
Ts = 1 / fs
t_cont = np.arange(0, 1, 0.0001)
x_cont = np.sin(2 * np.pi * f * t_cont)

t_all = np.arange(0, 1, Ts)       # All sample times
x_all = np.sin(2 * np.pi * f * t_all)  # All sample values
N_total = len(t_all)

# ==================================================
# Remove 30% of samples randomly
# ==================================================
loss_percentage = 0.30
N_keep = int(N_total * (1 - loss_percentage))

# Choose which samples to KEEP (random selection)
keep_indices = np.sort(np.random.choice(N_total, N_keep, replace=False))
# np.random.choice: pick N_keep unique indices from 0 to N_total-1
# np.sort: keep them in time order (important for interpolation!)

# Always keep first and last sample for interpolation to work well
if 0 not in keep_indices:
    keep_indices = np.concatenate(([0], keep_indices))
if N_total - 1 not in keep_indices:
    keep_indices = np.concatenate((keep_indices, [N_total - 1]))

t_available = t_all[keep_indices]     # Time points we have
x_available = x_all[keep_indices]     # Values we have

# Which samples were lost?
lost_indices = np.setdiff1d(np.arange(N_total), keep_indices)
# setdiff1d: elements in first array but NOT in second

t_lost = t_all[lost_indices]
x_lost = x_all[lost_indices]

print(f"Total samples: {N_total}")
print(f"Kept: {len(keep_indices)} ({100*(1-loss_percentage):.0f}%)")
print(f"Lost: {len(lost_indices)} ({100*loss_percentage:.0f}%)")

# ==================================================
# Reconstruction Method A: Linear Interpolation
# ==================================================
x_linear = np.interp(t_cont, t_available, x_available)
# np.interp uses the AVAILABLE (non-missing) samples
# and draws straight lines between them

# Also reconstruct at the LOST sample times to see accuracy
x_linear_at_lost = np.interp(t_lost, t_available, x_available)

# ==================================================
# Reconstruction Method B: Cubic Spline
# ==================================================
cs = CubicSpline(t_available, x_available)
x_cubic = cs(t_cont)
x_cubic_at_lost = cs(t_lost)

# ==================================================
# Error Analysis
# ==================================================
# Error over entire continuous signal
rms_linear = np.sqrt(np.mean((x_cont - x_linear) ** 2))
rms_cubic = np.sqrt(np.mean((x_cont - x_cubic) ** 2))

# Error specifically at the LOST sample points
# This tells us how well we predicted the missing values
rms_linear_lost = np.sqrt(np.mean((x_lost - x_linear_at_lost) ** 2))
rms_cubic_lost = np.sqrt(np.mean((x_lost - x_cubic_at_lost) ** 2))

# ==================================================
# Plot
# ==================================================
fig, axes = plt.subplots(3, 1, figsize=(14, 14))

# --- Plot 1: Show the data situation ---
axes[0].plot(t_cont, x_cont, 'b-', linewidth=2, alpha=0.3, label='Original signal')
axes[0].stem(t_available, x_available, linefmt='g-', markerfmt='go', 
              basefmt='k-', label=f'Available samples ({len(keep_indices)})')
axes[0].stem(t_lost, x_lost, linefmt='r-', markerfmt='rx', 
              basefmt='k-', label=f'Lost samples ({len(lost_indices)})')
axes[0].set_title(f'Sampling with {loss_percentage*100:.0f}% Data Loss')
axes[0].set_xlabel('Time (s)')
axes[0].set_ylabel('Amplitude')
axes[0].legend()
axes[0].grid(True, alpha=0.3)

# --- Plot 2: Linear interpolation reconstruction ---
axes[1].plot(t_cont, x_cont, 'b-', linewidth=2, alpha=0.3, label='Original')
axes[1].plot(t_cont, x_linear, 'g-', linewidth=1.5, label='Linear Interpolation')
axes[1].stem(t_available, x_available, linefmt='k-', markerfmt='ko', basefmt='k-')
# Show errors at lost points
for j in range(len(t_lost)):
    axes[1].plot([t_lost[j], t_lost[j]], [x_lost[j], x_linear_at_lost[j]], 
                  'r-', linewidth=1.5, alpha=0.5)
axes[1].set_title(f'Linear Interpolation | RMS Error = {rms_linear:.6f} | '
                   f'Error at lost points = {rms_linear_lost:.6f}')
axes[1].set_xlabel('Time (s)')
axes[1].set_ylabel('Amplitude')
axes[1].legend()
axes[1].grid(True, alpha=0.3)

# --- Plot 3: Cubic spline reconstruction ---
axes[2].plot(t_cont, x_cont, 'b-', linewidth=2, alpha=0.3, label='Original')
axes[2].plot(t_cont, x_cubic, 'm-', linewidth=1.5, label='Cubic Spline')
axes[2].stem(t_available, x_available, linefmt='k-', markerfmt='ko', basefmt='k-')
for j in range(len(t_lost)):
    axes[2].plot([t_lost[j], t_lost[j]], [x_lost[j], x_cubic_at_lost[j]], 
                  'r-', linewidth=1.5, alpha=0.5)
axes[2].set_title(f'Cubic Spline | RMS Error = {rms_cubic:.6f} | '
                   f'Error at lost points = {rms_cubic_lost:.6f}')
axes[2].set_xlabel('Time (s)')
axes[2].set_ylabel('Amplitude')
axes[2].legend()
axes[2].grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

# Summary
print(f"\n{'Method':<25} {'Overall RMS':>15} {'RMS at Lost Points':>20}")
print("-" * 62)
print(f"{'Linear Interpolation':<25} {rms_linear:>15.8f} {rms_linear_lost:>20.8f}")
print(f"{'Cubic Spline':<25} {rms_cubic:>15.8f} {rms_cubic_lost:>20.8f}")