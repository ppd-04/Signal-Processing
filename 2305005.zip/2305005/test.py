import numpy as np
import matplotlib.pyplot as plt

f = 5
fs = 50
duration = 1

t = np.arange(0, duration, 1/fs)
x = np.sin(2*np.pi*f*t)

plt.stem(t, x)
plt.xlabel("time")
plt.ylabel("amp")
plt.title("Sin")
plt.show()