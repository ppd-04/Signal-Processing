import numpy as np
import matplotlib.pyplot as plt

# ---- Original and sampled signals ----
f = 3  # Hz
fs = 15  # Sampling frequency
T = 1  # Duration

t_cont = np.arange(0, T, 0.0001)
x_cont = np.sin(2 * np.pi * f * t_cont)

t_s = np.arange(0, T, 1/fs)
x_s = np.sin(2 * np.pi * f * t_s)

# ---- Method 1: Zero-Order Hold (ZOH) ----
# Hold each sample value until the next sample
def zero_order_hold(t_recon, t_samples, x_samples):
    x_zoh = np.zeros(len(t_recon))
    for i in range(len(t_recon)):
        # Find the most recent sample at or before t_recon[i]
        idx = np.searchsorted(t_samples, t_recon[i], side='right') - 1
        idx = max(0, idx)  # Ensure non-negative
        x_zoh[i] = x_samples[idx]
    return x_zoh

x_zoh = zero_order_hold(t_cont, t_s, x_s)

# ---- Method 2: First-Order Hold (Linear Interpolation) ----
x_foh = np.interp(t_cont, t_s, x_s)
# np.interp does linear interpolation between sample points

# ---- Method 3: Sinc Interpolation ----
def sinc_interpolation(t_recon, t_samples, x_samples, Ts):
    x_sinc = np.zeros(len(t_recon))
    for n in range(len(t_samples)):
        x_sinc += x_samples[n] * np.sinc((t_recon - t_samples[n]) / Ts)
    return x_sinc

x_sinc = sinc_interpolation(t_cont, t_s, x_s, 1/fs)

# ---- Compute errors ----
error_zoh = np.sqrt(np.mean((x_cont - x_zoh) ** 2))    # RMS error
error_foh = np.sqrt(np.mean((x_cont - x_foh) ** 2))
error_sinc = np.sqrt(np.mean((x_cont - x_sinc) ** 2))

# ---- Plot ----
fig, axes = plt.subplots(3, 1, figsize=(14, 12))

methods = [
    ('Zero-Order Hold (Staircase)', x_zoh, error_zoh, 'r'),
    ('First-Order Hold (Linear Interpolation)', x_foh, error_foh, 'g'),
    ('Sinc Interpolation (Ideal)', x_sinc, error_sinc, 'm')
]

for i, (name, x_recon, error, color) in enumerate(methods):
    axes[i].plot(t_cont, x_cont, 'b-', linewidth=2, alpha=0.5, label='Original')
    axes[i].plot(t_cont, x_recon, f'{color}-', linewidth=1.5, label=name)
    axes[i].stem(t_s, x_s, linefmt='k-', markerfmt='ko', basefmt='k-', label='Samples')
    axes[i].set_title(f'{name} | RMS Error = {error:.6f}')
    axes[i].set_xlabel('Time (s)')
    axes[i].set_ylabel('Amplitude')
    axes[i].legend(loc='upper right')
    axes[i].grid(True)

plt.tight_layout()
plt.show()

# ---- Summary ----
print("\nReconstruction Quality Comparison:")
print(f"{'Method':<45} {'RMS Error':>12}")
print("-" * 58)
print(f"{'Zero-Order Hold (ZOH)':<45} {error_zoh:>12.6f}")
print(f"{'First-Order Hold (Linear)':<45} {error_foh:>12.6f}")
print(f"{'Sinc Interpolation (Ideal)':<45} {error_sinc:>12.6f}")