import numpy as np
import matplotlib.pyplot as plt

# ---- Generate original sampled signal ----
fs_original = 100  # Original sampling rate
T = 0.5            # Duration
t_original = np.arange(0, T, 1/fs_original)
N_original = len(t_original)

# Signal: 10 Hz + 20 Hz components
x_original = np.sin(2*np.pi*10*t_original) + 0.5*np.sin(2*np.pi*20*t_original)

# ===== (a) DOWNSAMPLING by factor M = 4 =====
M = 4
x_downsampled = x_original[::M]  # Take every M-th sample
# ::M means start:stop:step → takes indices 0, 4, 8, 12, ...
t_downsampled = t_original[::M]
fs_down = fs_original / M  # New fs = 25 Hz
print(f"Downsampling: {fs_original} Hz → {fs_down} Hz")
print(f"Original samples: {len(x_original)}, After downsampling: {len(x_downsampled)}")

# ===== (b) UPSAMPLING by factor L = 3 =====
L = 3

# Step 1: Zero insertion
# Insert (L-1) zeros between each sample
x_zero_inserted = np.zeros(len(x_original) * L)
x_zero_inserted[::L] = x_original  # Place original samples every L positions
t_upsampled = np.arange(0, T, 1/(fs_original * L))
t_upsampled = t_upsampled[:len(x_zero_inserted)]  # Match lengths

fs_up = fs_original * L  # New fs = 300 Hz

# Step 2: Low-pass filter (interpolation)
# Simple moving average filter as basic interpolation
# For proper interpolation, use a sinc-based filter
from numpy import convolve

# Design a simple low-pass FIR filter (sinc filter)
# Cutoff frequency should be at fs_original/2 = 50 Hz
num_taps = 31  # Filter length (odd number)
n_filter = np.arange(num_taps)
center = (num_taps - 1) / 2

# Normalized cutoff: fc / (fs_up/2) = (fs_original/2) / (fs_up/2) = 1/L
fc_normalized = 1 / L
h = L * fc_normalized * np.sinc(fc_normalized * (n_filter - center))  
# L * because upsampling reduces amplitude by factor L

# Apply window (Hamming) to reduce ripples
window = np.hamming(num_taps)
h = h * window

# Apply filter
x_upsampled = np.convolve(x_zero_inserted, h, mode='same')

print(f"\nUpsampling: {fs_original} Hz → {fs_up} Hz")
print(f"Original samples: {len(x_original)}, After upsampling: {len(x_upsampled)}")

# ---- Compute spectra ----
def compute_spectrum(x, fs):
    N = len(x)
    X = np.fft.fft(x)
    freqs = np.fft.fftfreq(N, 1/fs)
    mag = np.abs(X) / N * 2
    pos = freqs >= 0
    return freqs[pos], mag[pos]

freq_orig, mag_orig = compute_spectrum(x_original, fs_original)
freq_down, mag_down = compute_spectrum(x_downsampled, fs_down)
freq_up, mag_up = compute_spectrum(x_upsampled, fs_up)

# ---- Plot everything ----
fig, axes = plt.subplots(3, 2, figsize=(14, 10))

# Original
axes[0][0].stem(t_original, x_original, linefmt='b-', markerfmt='b.', basefmt='k-')
axes[0][0].set_title(f'Original Signal (fs={fs_original} Hz, N={len(x_original)})')
axes[0][0].set_xlabel('Time (s)')
axes[0][0].grid(True)

axes[0][1].stem(freq_orig, mag_orig, linefmt='b-', markerfmt='b.', basefmt='k-')
axes[0][1].set_title('Original Spectrum')
axes[0][1].set_xlabel('Frequency (Hz)')
axes[0][1].set_xlim(0, fs_original/2)
axes[0][1].grid(True)

# Downsampled
axes[1][0].stem(t_downsampled, x_downsampled, linefmt='r-', markerfmt='ro', basefmt='k-')
axes[1][0].set_title(f'Downsampled by {M} (fs={fs_down} Hz, N={len(x_downsampled)})')
axes[1][0].set_xlabel('Time (s)')
axes[1][0].grid(True)

axes[1][1].stem(freq_down, mag_down, linefmt='r-', markerfmt='ro', basefmt='k-')
axes[1][1].set_title(f'Downsampled Spectrum (Nyquist = {fs_down/2} Hz)')
axes[1][1].set_xlabel('Frequency (Hz)')
axes[1][1].set_xlim(0, fs_down/2)
axes[1][1].grid(True)

# Upsampled
axes[2][0].stem(t_upsampled, x_upsampled, linefmt='g-', markerfmt='g.', basefmt='k-')
axes[2][0].set_title(f'Upsampled by {L} (fs={fs_up} Hz, N={len(x_upsampled)})')
axes[2][0].set_xlabel('Time (s)')
axes[2][0].grid(True)

axes[2][1].stem(freq_up, mag_up, linefmt='g-', markerfmt='g.', basefmt='k-')
axes[2][1].set_title(f'Upsampled Spectrum')
axes[2][1].set_xlabel('Frequency (Hz)')
axes[2][1].set_xlim(0, fs_up/2)
axes[2][1].grid(True)

plt.tight_layout()
plt.show()