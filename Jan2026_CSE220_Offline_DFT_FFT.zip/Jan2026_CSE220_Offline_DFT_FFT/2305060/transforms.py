"""
transforms.py  --  YOUR CODE GOES HERE.

The shared transform core used by BOTH tasks. Write it once; bigmul.py
(Task A) and image_conv.py (Task B) import it.

Nothing in this file may call numpy.fft, scipy.fft, numpy.convolve,
scipy.signal, or any other library routine that performs a Fourier
transform, a convolution or a correlation for you. NumPy is for array
arithmetic only.

A quick self-test you should run before touching either application:

    import numpy as np
    from transforms import DFTAnalyzer, FFTTransformer
    x = np.random.randn(64) + 1j * np.random.randn(64)
    d, f = DFTAnalyzer(), FFTTransformer()
    assert np.max(np.abs(d.transform(x) - f.transform(x))) < 1e-9
    assert np.max(np.abs(d.inverse(d.transform(x)) - x)) < 1e-9
"""

import numpy as np


def next_power_of_two(n):
    """
    Return the smallest power of two that is >= ``n`` (and at least 1).

    Both tasks need this to choose a transform length for the radix-2 FFT.
    """
    # TODO: implement this function
    # raise NotImplementedError("Implement next_power_of_two")
    if n<=1:
        return 1
    return 1 << (n-1).bit_length()


class DFTAnalyzer:
    """
    The Discrete Fourier Transform, computed straight from its definition.

        Analysis:   X[k] = sum_{n=0}^{N-1} x[n] * exp(-2j*pi*k*n/N)
        Synthesis:  x[n] = (1/N) * sum_{k=0}^{N-1} X[k] * exp(+2j*pi*k*n/N)

    How you write it is up to you -- a literal double loop, a precomputed
    table of twiddle factors indexed by (k*n) % N, or a NumPy expression --
    as long as it computes these sums directly and is not secretly an FFT.
    """

    name = "dft"

    def transform(self, x):
        """
        Forward DFT.

        Parameters
        ----------
        x : 1D array_like, length N (real or complex)

        Returns
        -------
        numpy.ndarray of complex128, shape (N,)
        """
        # TODO: implement this method
        # raise NotImplementedError("Implement DFTAnalyzer.transform")
        x = np.asarray(x, dtype=np.complex128)
        N = len(x)
        n = np.arange(N)
        k = n[:, np.newaxis]
        W = np.exp(-2j*np.pi*k*n/N)
        # @ diye matrix vector product hoy wow
        return W@x


    def inverse(self, spectrum):
        """
        Inverse DFT, including the 1/N factor.

        Parameters
        ----------
        spectrum : 1D array_like, length N (complex)

        Returns
        -------
        numpy.ndarray of complex128, shape (N,)
            Do NOT discard the imaginary part here -- the caller decides when
            it is safe to take .real.
        """
        # TODO: implement this method
        # raise NotImplementedError("Implement DFTAnalyzer.inverse")
        spectrum = np.asarray(spectrum, dtype=np.complex128)
        N = len(spectrum)
        n = np.arange(N)
        k = n[:, np.newaxis]
        W = np.exp(+2j*np.pi * k * n/N)
        return (W@spectrum)/N


class FFTTransformer(DFTAnalyzer):
    """
    Radix-2 decimation-in-time (Cooley-Tukey) FFT, in O(N log N).

    It inherits from DFTAnalyzer so that both applications can treat the two
    interchangeably: they call ``engine.transform(...)`` and
    ``engine.inverse(...)`` without caring which engine they hold.

    Requirements:
      * Recursive or iterative (with bit-reversal permutation) -- your choice.
      * N must be a power of two; raise ValueError for any other length.
        The caller is responsible for zero-padding up to next_power_of_two.
      * The inverse must reuse the same butterfly machinery (conjugated
        twiddles, or conjugate-transform-conjugate), not a second copy of it.
      * Twiddle factors for a stage are computed once per stage, never once
        per butterfly.
    """

    name = "fft"

    # run hote late hoy cause bishal boro number

    def __init__(self):
        super().__init__()
        self._twiddle_cache={}

    def fft_recursive(self, x):
        N = len(x)
        if N ==1:
            return x.copy()
        jorPart = self.fft_recursive(x[0::2])
        bijorPart = self.fft_recursive(x[1::2])
        # k = np.arange(N//2)
        # toka = np.exp(-2j*np.pi*k/N)
        # changing

        if N not in self._twiddle_cache:
            k  = np.arange(N//2)
            self._twiddle_cache[N] = np.exp(-2j*np.pi*k/N)

        # toka mane W, twiddle arki
        toka  = self._twiddle_cache[N]

        t = toka*bijorPart
        prothomPart = jorPart+t
        # sad ei vul ber korte etokkhon
        sheshPart = jorPart-t
        return np.concatenate([prothomPart, sheshPart])

    def transform(self, x):
        """Forward FFT. Same contract as DFTAnalyzer.transform."""
        # TODO: implement this method
        # raise NotImplementedError("Implement FFTTransformer.transform")
        x = np.asarray(x, dtype=np.complex128)
        N = len(x)
        if N==0:
            return x.copy()

        # n power of 2 hole exactdly 1 ta bit one hoy. so erporer gular sathe and korle 0 asha uchit 
        if N & (N-1)!=0:
            # 2 er power 1bit er hoise
            raise ValueError(f"Transformation requires power of 2 length")
        return self.fft_recursive(x)

    def inverse(self, spectrum):
        """Inverse FFT, including the 1/N factor."""
        # TODO: implement this method
        # raise NotImplementedError("Implement FFTTransformer.inverse")
        spectrum = np.asarray(spectrum, dtype=np.complex128)
        N = len(spectrum)
        if N == 0:
            return spectrum.copy()
        if N & (N-1):
            raise ValueError(f"Transformation requires power of 2 length")
        return np.conj(self.transform(np.conj(spectrum)))/N
        


# ---------------------------------------------------------------------------
# BONUS (optional) -- arbitrary-length FFT.
#
# Delete this class if you are not attempting the bonus. If you do attempt it,
# run both tasks with --engine arbitrary and leave those output directories in
# your submission as the evidence.
# ---------------------------------------------------------------------------
class ArbitraryLengthFFT(FFTTransformer):
    """
    Bonus: an O(N log N) transform for ANY length N, not just powers of two.

    Bluestein's chirp-z algorithm is the usual route: rewrite the DFT as a
    convolution of two chirp sequences, and evaluate that convolution with a
    radix-2 FFT of length >= 2N-1. A mixed-radix Cooley-Tukey that factorises
    N is equally acceptable.

    With this engine, Task A no longer has to pad the digit arrays up to a
    power of two, and Task B no longer has to pad the image up to one.
    """

    name = "arbitrary"

    def transform(self, x):
        # TODO (bonus): implement this method
        # raise NotImplementedError("Bonus: implement ArbitraryLengthFFT.transform")
        x = np.asarray(x, dtype=np.complex128)
        N = len(x)
        if N == 0:
            return super().transform(x)

        # n 2 er power hole normal fft use korbo, bluestein lagbena
        if N & (N-1) == 0:
            return super().transform(x)

        m = np.arange(N)
        chirp = np.exp(-1j*np.pi*m*m/N)
        a = x*chirp
        b = np.conj(chirp)
        M = next_power_of_two(2*N-1)
        aPadded= np.zeros(M, dtype=np.complex128)
        aPadded[:N]=a
        bPadded = np.zeros(M, dtype=np.complex128)
        bPadded[:N] = b
        bPadded[M-N+1:] = b[1:][::-1]

        A  = super().transform(aPadded)
        B = super().transform(bPadded)
        conv = super().inverse(A*B)
        X = chirp*conv[:N]
        return X

    def inverse(self, spectrum):
        # TODO (bonus): implement this method
        # raise NotImplementedError("Bonus: implement ArbitraryLengthFFT.inverse")
        spectrum = np.asarray(spectrum, dtype=np.complex128)
        N = len(spectrum)
        if N==0:
            return spectrum.copy()
        return np.conj(self.transform(np.conj(spectrum)))/N
