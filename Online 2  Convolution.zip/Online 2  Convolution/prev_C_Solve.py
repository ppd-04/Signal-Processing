import numpy as np
import matplotlib.pyplot as plt

# Todo: Define Signal class
        
class SuperSignal:
    def __init__(self):
        self.components = []

    def add(self, signal: Signal, coefficient=1.0):
        self.components.append((coefficient, signal))
        
# Todo: Define LTI class
# LTI SYSTEM e dhuukate hobe

def output_super(self, super_signal):
    result = None
    for coefficient, sig in super_signal.components:
        y = self.output(sig)
        y_scaled = y.multiply(coefficient)
        if result is None:
            result = y_scaled
        else:
            result = result.add(y_scaled)
    return result



if __name__ == "__main__":
    INF = 10

    # Component signals
    x1 = DiscreteSignal(INF)
    x1.set_value_at_time(0, 1)

    x2 = DiscreteSignal(INF)
    x2.set_value_at_time(2, 1)

    # Todo: Create SuperSignal: x(n) = 2*x1(n) - x2(n)
    X = SuperSignal()
    X.add(x1, 2)
    X.add(x2, -1)


    # Impulse response
    h = DiscreteSignal(INF)
    h.set_value_at_time(0, 1)
    h.set_value_at_time(1, 0.5)

    system = LTISystem(h)

    # Todo: Output using superposition
    y_super = system.output_super(X)
    x_direct = x1.multiply(2).add(x2.multiply(-1))   # x = 2*x1 - x2
y_direct = system.output(x_direct)

# verify both match
diff = max_absolute_difference(y_super, y_direct)
print(f"Max difference: {diff}") 