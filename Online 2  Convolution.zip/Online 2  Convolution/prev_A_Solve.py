import os
import argparse

os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-cache")

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np

from signal_lti import DiscreteSignal, LTISystem, readable_time_ticks


def first_difference(sig):
    return sig.add(sig.shift(1).multiply(-1))


def main2():
    h = first_difference(s)

    deltaX = first_difference(x)

    ysd = LTISystem(s).output(deltaX)
    yh = LTISystem.outptut(x)
    diff = max_absolute_difference(ysd, yh)

# def main2():
#     os.makedirs("outputs", exist_ok=True)

#     # TASK 1: read files
#     # parse_signal needs lines + index, so use read_nonempty_lines first
#     s_lines = read_nonempty_lines("step_response.txt")
#     x_lines = read_nonempty_lines("input_signal.txt")
#     s, _ = parse_signal(s_lines, 0)   # your existing parse_signal
#     x, _ = parse_signal(x_lines, 0)   # your existing parse_signal

#     print(print_signal(s, "Step response s[n]"))
#     print(print_signal(x, "Input signal x[n]"))

#     # TASK 2: recover h[n] = s[n] - s[n-1]
#     h = first_difference(s)
#     print(print_signal(h, "Impulse response h[n]"))
#     # plot s and h using your existing plot_signals_as_stems
#     # it needs 3 signals, so pass s as "input", h as "impulse", h as "output"
#     plot_signals_as_stems(s, h, h, "outputs/step_and_impulse.png")

#     # TASK 3: delta_x[n] = x[n] - x[n-1]
#     delta_x = first_difference(x)
#     print(print_signal(delta_x, "delta_x[n]"))

#     # TASK 4: ys = delta_x * s  (step response method)
#     ys = LTISystem(s).output(delta_x)   # your LTISystem does convolution
#     print(print_signal(ys, "ys[n] = delta_x * s"))

#     # TASK 5: yh = x * h  (impulse response method, for verification)
#     yh = LTISystem(h).output(x)
#     print(print_signal(yh, "yh[n] = x * h"))

#     # compare both outputs, should be ~0
#     diff = max_absolute_difference(ys, yh)
#     print(f"Max difference between ys and yh: {diff:.2e}")

#     # plot comparison using your existing function
#     plot_signals_as_stems(delta_x, s, ys, "outputs/output_step.png")
#     plot_signals_as_stems(x, h, yh, "outputs/output_impulse.png")


# if __name__ == "__main__":
#     main2()

if __name__ == "__main__":
    main()
