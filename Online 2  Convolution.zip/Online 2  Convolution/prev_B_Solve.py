import numpy as np
import matplotlib.pyplot as plt

import main
import signal_lti
# Todo: Define Signal class

# Todo: Define LTI class

if __name__ == "__main__":
    INF = 10

    x = DiscreteSignal(0, INF)
    x.set_value_at_time(0, 1)
    x.set_value_at_time(2, -1)
    x.plot("Input x(n)")

    h1 = DiscreteSignal(0, INF)
    h1.set_value_at_time(0, 1)

    h2 = DiscreteSignal(0,INF)
    h2.set_value_at_time(1, 0.5)

    h3 = DiscreteSignal(0,INF)
    h3.set_value_at_time(0, 1)
    h3.set_value_at_time(1, 1)

    sys1 = LTISystem(h1)
    sys2 = LTISystem(h2)
    sys3 = LTISystem(h3)
    
    # Todo: Determine output block by block
    y1 = sys1.output(x)
    y2 = sys2.output(x)
    y_sum = y1.add(y2)
    y_final_1 = sys3.output(y_sum)

    y_final_1.plot("Output via block-by-block system")

    # Todo: Determine h_combined
    h_parallel = h1.add(h2)
    h_combined = LTISystem(h3).output(h_parallel)
    
    sys_combined = LTI_System(h_combined)



    y_final_2 = sys_combined.output(x)
    y_final_2.plot("Output via combined impulse response")


    diff = max_absolute_difference(y_final_1, y_final_2)
    print(f"Max difference: {diff}")
    print("Outputs are equal:",
          np.allclose(y_final_1.values, y_final_2.values))