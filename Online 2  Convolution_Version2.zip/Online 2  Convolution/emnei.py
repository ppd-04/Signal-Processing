import numpy as np
from signal_lti import DiscreteSignal, LTISystem, readable_time_ticks
from main import *

x = make_signal(0, 3, [1, 2, 3, 4])
h = make_signal(1, 5, [3, 4, 5, 6, 7])
h1 = make_signal(0, 2, [0.5, 0.3, 0.2])

# h2 spans from n = 0 to 1 with values [1.0, -1.0] (first difference)
h2 = make_signal(0, 1, [1.0, -1.0])
h3 = make_signal(0, 1, [1.0, -0.5])
# subtraction
# x[n]-x[n-1]

result = x.add(x.shift(1).multiply(-1))


k=2
x_delayed = x.shift(k)

# convolve kora
# y=x*h

result = LTISystem(h).output(x)

# \compare korar jonno
diff = max_absolute_difference(x, y)

# prev a solve
def first_difference(sig:DiscreteSignal):
    return sig.add(sig.shift(1).multiply(-1))

# parallel series
# prev B solve
#way 1
y1 = LTISystem(h1).output(x)
y2 = LTISystem(h2).output(x)
y_sum = y1.add(y2)
y_way1 = LTISystem(h3).output(y_sum)

# another way
h_parallel = h1.add(h2)
h_combined = LTISystem(h3).output(h_parallel)
y_way2 = LTISystem(h_combined).output(x)

diff = max_absolute_difference(y_way1, y_way2)

#Super signal
#inside ltisystem
class SuperSignal:
    def __init__(self):
        self.components = []
    def add(self, signal, coef=1.0):
        self.components.append(coef, signal)

    # signals
    # signals.add(signal.multiply(coef))
    # signal_from_samples sustem

    #superposition na lagle
    # Build the actual combined input signal x = 2*x1 - x2
    x_direct = x1.multiply(2).add(x2.multiply(-1))

    # Then just do normal convolution (same as Offline 1)
    y_direct = system.output(x_direct)

    def output_super(self, super_signal):
        result = None
        for coeff, sig in super_signal.components:
            y = self.output(sig)
            y_scaled = y.multiply(coeff)
        if result is None:
            result = y_scaled
        else:
            result = result.add(y_scaled)
        return result

    # (x*h1)*h2=(x*(h1*h2))
    y1 = LTISystem(h2).output(LTISystem(h1).output(x))
    y2 = LTISystem(LTISystem(h2).output(h1)).output(x)

    # x*(h1+h2)=x*h1+x*h2
    y1 = LTISystem(h1.add(h2)).output(x)
    y2 = (LTISystem(h1).output(x)).add(LTISystem(h2).output(x))


    # Type 5: Find Output for Shifted/Scaled Input
    y = LTISystem(h).output(x)

    x_shifted = x.shift(3)
    y_shifted = LTISystem(h).output(x_shifted)
    y_anotherShifted = y.shift(3)
    # so y_shifted  should be equalto yanothershifted

    x_scaled = x. multiply (5)
    y_scaled = LTISystem (h). output ( x_scaled )


#     1. h[k] = alpha * (1-alpha)^k    for k = 0, 1, ..., n-1
# 2. Convolve x with h              using LTISystem(h).output(x)
# 3. Take indices [n-1, m-1]        using range(n-1, m)

    def exponential_smoothing(prices, n, alpha):
        m = len(prices)
        x = make_signal(0, m-1, prices)
        h_values = [alpha*(1-alpha)**k for k in range(n)]
        h = make_signal(0, n-1, h_values)

        y = LTISystem(h).output(x)

        result = [y.get_value_at_time(i) for i in range(n-1, m)]
        return result

    def againExponentialSmotthing(prices, n, alpha):
        m = len(prices)
        x = make_signal(0, m-1, prices)
        h_val = [alpha*(1-alpha)**k for k in range(n)]
        h = make_signal(0, n-1, h_val)
        y = LTISystem(h).output(x)
        result = [y.get_value_at_time(k) for k in range(n-1, m)]
        return result

    def unweighted_moving_avg(prices, n):
        m = len(prices)
        x = make_signal(0, m-1, prices)
        h_val = [1/n]*n
        h = make_signal(0, n-1, h_val)
        y = LTISystem(h).output(x)
        return [y.get_value_at_time(i) for i in range(n-1, m)]

    def weighted_moving_average(prices, n):
        m = len(prices)
        x = make_signal(0, m-1, prices)
        total = n*(n+1)/2
        h_values = [(n-k)/total for k in range(n)]
        h = make_signal(0, n-1, h_values)

        y = LTISystem(h).output(x)

        return [y.get_value_at_time(i) for i in range(n-1, m)]

    def polynomial_multiply(coeffs_a, coeffs_b):
        d1 = len(coeffs_a)-1
        d2 = len(coeffs_b)-1

        a_values = coeffs_a[::-1]
        b_values = coeffs_b[::-1]

        x = make_signal(0, d1, a_values)
        h = make_signal(0, d2, b_values)

        y = LTISystem(h).output(x)

        result = [y.get_value_at_time(k) for k in range(d1+d2+1)]
        return result[::-1]

# main function for polynomial
# if __name__ == "__main__":
#     # first polynomial
#     d1 = int(input("Degree of the first Polynomial: "))
#     coeffs_a = list(map(int, input("Coefficients: ").split()))
    
#     # second polynomial
#     d2 = int(input("Degree of the second Polynomial: "))
#     coeffs_b = list(map(int, input("Coefficients: ").split()))
    
#     # multiply
#     result = polynomial_multiply(coeffs_a, coeffs_b)
    
#     # print output
#     print(f"Degree of the Polynomial: {d1 + d2}")
#     print("Coefficients:", " ".join(str(int(v)) for v in result))