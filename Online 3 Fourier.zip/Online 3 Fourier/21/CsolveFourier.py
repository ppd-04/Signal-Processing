import numpy as np
import matplotlib.pyplot as plt

# ════════════════════════════════════════════════
# SignalAnalyzer class
# Handles everything: signal, CFT, reconstruction
# ════════════════════════════════════════════════

class SignalAnalyzer:

    def __init__(self, t, f):
        """
        t : time axis
        f : frequency axis
        """
        self.t = t
        self.f = f

    def original_signal(self):
        """
        The given complicated function:
        f(t) = 2sin(14πt) - sin(2πt)(4sin(2πt)sin(14πt) - 1)

        Just compute it directly using numpy.
        """
        t   = self.t
        ft  = 2*np.sin(14*np.pi*t) \
            - np.sin(2*np.pi*t) * (4*np.sin(2*np.pi*t)*np.sin(14*np.pi*t) - 1)
        return ft

    def compute_cft(self, signal):
        """
        CFT: X(f) = ∫ x(t) · e^(-j2πft) dt
        Same as all previous problems.
        Use trapezoid for integration.
        """
        X = np.zeros(len(self.f), dtype=complex)

        for i, fi in enumerate(self.f):
            kernel = np.cos(2*np.pi*fi*self.t) \
                   - 1j*np.sin(2*np.pi*fi*self.t)
            X[i]   = np.trapezoid(signal * kernel, self.t)

        return X

    def find_frequencies(self, X, threshold=0.5):
        """
        Look at |X(f)| and find PEAKS.
        A peak = a frequency that is present in the signal.

        threshold : minimum magnitude to count as a real peak
                    (ignores tiny numerical noise)

        How peak finding works:
        - Look at each point in |X(f)|
        - If it's bigger than its neighbors → it's a peak
        - If its magnitude > threshold → it's a real frequency
        """
        mag = np.abs(X)

        # Find indices where magnitude is a local peak
        # mag[i] > mag[i-1] AND mag[i] > mag[i+1]
        peaks = []
        for i in range(1, len(mag)-1):
            if mag[i] > mag[i-1] and mag[i] > mag[i+1]:
                if mag[i] > threshold:
                    peaks.append(i)

        # Get frequency values at peak indices
        # Only keep positive frequencies (spectrum is symmetric)
        found_freqs = []
        for idx in peaks:
            freq = self.f[idx]
            if freq > 0:  # only positive frequencies
                found_freqs.append(round(freq, 2))

        return found_freqs

    def reconstruct(self, frequencies):
        """
        Reconstruct signal from discovered frequencies.

        Since problem says: amplitude=1, phase=0 for all components
        Each component is simply: sin(2πft)

        f(t) = Σ sin(2π × freq × t)
               for each freq in frequencies
        """
        result = np.zeros(len(self.t))

        for freq in frequencies:
            # amplitude=1, phase=0 → just sin(2πft)
            result += np.sin(2 * np.pi * freq * self.t)

        return result

    def compute_mse(self, signal1, signal2):
        """
        MSE = mean(|signal1 - signal2|²)
        Small MSE → reconstruction matches original ✓
        """
        return np.mean((signal1 - signal2)**2)

    def run(self):
        """
        Main method: runs all steps in order
        """

        # ── Step 1: Compute original signal ──
        print("Step 1: Computing original signal...")
        ft = self.original_signal()

        # ── Step 2: Compute CFT ──
        print("Step 2: Computing CFT...")
        X  = self.compute_cft(ft)

        # ── Step 3: Find frequencies from peaks ──
        print("Step 3: Finding frequencies...")
        freqs = self.find_frequencies(X, threshold=0.5)
        print(f"  Discovered frequencies: {freqs} Hz")

        # ── Step 4: Reconstruct ──
        print("Step 4: Reconstructing signal...")
        ft_reconstructed = self.reconstruct(freqs)

        # ── Step 5: MSE ──
        error = self.compute_mse(ft, ft_reconstructed)
        print(f"\n  MSE between original and reconstruction: {error:.6e}")
        if error < 1e-6:
            print("  ✓ Reconstruction matches original perfectly!")

        # ── Step 6: Plot ──
        self.plot(ft, X, freqs, ft_reconstructed, error)

    def plot(self, ft, X, freqs, ft_reconstructed, error):
        """
        4 plots:
        1. Original f(t)
        2. |X(f)| magnitude spectrum with peaks marked
        3. Reconstructed signal
        4. Comparison: original vs reconstructed
        """
        fig, axes = plt.subplots(2, 2, figsize=(13, 9))
        fig.suptitle("Frequency Discovery and Signal Reconstruction",
                     fontsize=13, fontweight='bold')

        # Plot 1: Original signal
        axes[0,0].plot(self.t, ft, 'b-', lw=1.5)
        axes[0,0].set_title('Original f(t) = 2sin(14πt) - sin(2πt)(4sin(2πt)sin(14πt)-1)')
        axes[0,0].set_xlabel('Time t (seconds)')
        axes[0,0].set_ylabel('Amplitude')
        axes[0,0].grid(True, alpha=0.3)

        # Plot 2: Magnitude spectrum with peaks marked
        axes[0,1].plot(self.f, np.abs(X), 'b-', lw=1.5, label='|X(f)|')
        # Mark discovered peaks with red dots
        for freq in freqs:
            # Find index closest to this frequency
            idx = np.argmin(np.abs(self.f - freq))
            axes[0,1].plot(freq, np.abs(X[idx]),
                           'ro', markersize=10,
                           label=f'f={freq}Hz')
        axes[0,1].set_title('Magnitude Spectrum |X(f)| — Peaks = Hidden Frequencies')
        axes[0,1].set_xlabel('Frequency f (Hz)')
        axes[0,1].set_ylabel('|X(f)|')
        axes[0,1].legend()
        axes[0,1].grid(True, alpha=0.3)

        # Plot 3: Each component separately + reconstruction
        axes[1,0].set_title('Individual Components')
        colors = ['r', 'g', 'm']
        for i, freq in enumerate(freqs):
            component = np.sin(2 * np.pi * freq * self.t)
            axes[1,0].plot(self.t, component,
                          color=colors[i % len(colors)],
                          lw=1.5, alpha=0.7,
                          label=f'sin(2π×{freq}×t)')
        axes[1,0].set_xlabel('Time t')
        axes[1,0].set_ylabel('Amplitude')
        axes[1,0].legend()
        axes[1,0].grid(True, alpha=0.3)

        # Plot 4: Original vs Reconstruction
        axes[1,1].plot(self.t, ft,               'b-',
                       lw=2.5, label='Original f(t)',    alpha=0.7)
        axes[1,1].plot(self.t, ft_reconstructed, 'r--',
                       lw=1.5, label='Reconstructed')
        axes[1,1].set_title(f'Original vs Reconstructed (MSE={error:.2e})')
        axes[1,1].set_xlabel('Time t')
        axes[1,1].set_ylabel('Amplitude')
        axes[1,1].legend()
        axes[1,1].grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()


# ════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════

if __name__ == "__main__":

    # Time axis: enough cycles to see all frequencies
    # f1=1Hz, f2=5Hz, f3=9Hz
    # Need at least a few cycles of lowest frequency (1Hz)
    t = np.linspace(-2, 2, 5000)

    # Frequency axis: need to see up to ~10Hz
    f = np.linspace(-15, 15, 3000)

    analyzer = SignalAnalyzer(t, f)
    analyzer.run()