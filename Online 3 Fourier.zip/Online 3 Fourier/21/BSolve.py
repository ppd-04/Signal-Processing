import numpy as np
import matplotlib.pyplot as plt

class ParsevalVerifier:

    def __init__(self, t, f):
        """
        t : time axis
        f : frequency axis
        """
        self.t = t
        self.f = f

    # ─────────────────────────────────────────
    # Step 1: Define the piecewise signal
    # ─────────────────────────────────────────
    def signal(self):
        """
        Piecewise function over [-3, 3]:

        f(t) = (|t| - 3)²   for 1 < |t| ≤ 3   (parabola on sides)
        f(t) = 1 - t²        for |t| ≤ 1        (parabola in middle)
        f(t) = 0             otherwise
        
        np.where works like:
        np.where(condition, value_if_true, value_if_false)
        We nest them for multiple conditions.
        """
        t  = self.t
        ft = np.where(
                np.abs(t) <= 1,
                1 - t**2,                    # middle: upside down parabola
                np.where(
                    np.abs(t) <= 3,
                    (np.abs(t) - 3)**2,      # sides: parabola going to 0
                    0.0                       # outside: zero
                )
             )
        return ft

    # ─────────────────────────────────────────
    # Step 2: CFT — same as previous problems
    # From your offline code
    # ─────────────────────────────────────────
    def compute_cft(self, ft):
        """
        X(f) = ∫ f(t) · e^(-j2πft) dt
             = ∫ f(t) · [cos(2πft) - j·sin(2πft)] dt

        Same as all previous problems.
        Same as your calculate_cn() pattern.
        """
        X = np.zeros(len(self.f), dtype=complex)

        for i, fi in enumerate(self.f):
            kernel = np.cos(2*np.pi*fi*self.t) \
                   - 1j*np.sin(2*np.pi*fi*self.t)
            X[i]   = np.trapezoid(ft * kernel, self.t)

        return X

    # ─────────────────────────────────────────
    # Step 3: IFT — inverse Fourier Transform
    # From your offline code
    # ─────────────────────────────────────────
    def compute_ift(self, X):
        """
        f(t) = ∫ X(f) · e^(+j2πft) df
             = ∫ X(f) · [cos(2πft) + j·sin(2πft)] df

        SAME as CFT but:
        → sign flipped: +j instead of -j
        → integrate over f instead of t
        → use self.f as axis
        """
        ft_reconstructed = np.zeros(len(self.t), dtype=complex)

        for i, ti in enumerate(self.t):
            # +j·sin (positive sign for inverse!)
            kernel              = np.cos(2*np.pi*self.f*ti) \
                                + 1j*np.sin(2*np.pi*self.f*ti)
            ft_reconstructed[i] = np.trapezoid(X * kernel, self.f)

        return np.real(ft_reconstructed)

    # ─────────────────────────────────────────
    # Step 4: Parseval's Theorem
    # ─────────────────────────────────────────
    def parseval(self, ft, X):
        """
        Left side:  ∫ |f(t)|² dt  → energy in time domain
        Right side: ∫ |F(f)|² df  → energy in frequency domain

        Both computed using trapezoid.
        They should be equal!
        """
        # Energy in time domain
        # |f(t)|² = f(t)² for real signal
        energy_time = np.trapezoid(np.abs(ft)**2, self.t)

        # Energy in frequency domain
        # |F(f)|² = F(f) × F*(f) = real² + imag²
        energy_freq = np.trapezoid(np.abs(X)**2,  self.f)

        return energy_time, energy_freq

    # ─────────────────────────────────────────
    # Step 5: MSE between original and IFT
    # ─────────────────────────────────────────
    def mse(self, a, b):
        return np.mean((a - b)**2)

    # ─────────────────────────────────────────
    # Run everything
    # ─────────────────────────────────────────
    def run(self):

        # Step 1: Original signal
        ft      = self.signal()

        # Step 2: CFT
        print("Computing CFT...")
        X       = self.compute_cft(ft)

        # Step 3: IFT (reconstruct back)
        print("Computing IFT...")
        ft_back = self.compute_ift(X)

        # Step 4: Parseval check
        E_time, E_freq = self.parseval(ft, X)
        print(f"\n======= Parseval's Theorem =======")
        print(f"Energy (time domain) : {E_time:.6f}")
        print(f"Energy (freq domain) : {E_freq:.6f}")
        print(f"Difference           : {abs(E_time - E_freq):.2e}")
        if abs(E_time - E_freq) < 1e-3:
            print("✓ Parseval's theorem VERIFIED!")
        print(f"==================================\n")

        # Step 5: MSE between original and reconstructed
        error = self.mse(ft, ft_back)
        print(f"MSE (original vs IFT): {error:.2e}")

        # Step 6: Plot
        self.plot(ft, X, ft_back, E_time, E_freq)

    # ─────────────────────────────────────────
    # Plotting
    # ─────────────────────────────────────────
    def plot(self, ft, X, ft_back, E_time, E_freq):

        fig, axes = plt.subplots(2, 2, figsize=(13, 9))
        fig.suptitle("Parseval's Theorem Verification", fontsize=13)

        # Plot 1: Original piecewise signal
        axes[0,0].plot(self.t, ft, 'b-', lw=2)
        axes[0,0].set_title('Original Piecewise Signal f(t)')
        axes[0,0].set_xlabel('t')
        axes[0,0].set_ylabel('f(t)')
        axes[0,0].axhline(0, color='k', lw=0.5)
        axes[0,0].grid(True, alpha=0.3)

        # Plot 2: Magnitude spectrum |X(f)|
        axes[0,1].plot(self.f, np.abs(X), 'r-', lw=1.5)
        axes[0,1].set_title('Magnitude Spectrum |X(f)|')
        axes[0,1].set_xlabel('f (Hz)')
        axes[0,1].set_ylabel('|X(f)|')
        axes[0,1].grid(True, alpha=0.3)

        # Plot 3: Original vs IFT reconstruction
        axes[1,0].plot(self.t, ft,      'b-',
                       lw=3, label='Original f(t)',    alpha=0.6)
        axes[1,0].plot(self.t, ft_back, 'r--',
                       lw=1.5, label='Reconstructed (IFT)')
        axes[1,0].set_title('Original vs IFT Reconstruction')
        axes[1,0].set_xlabel('t')
        axes[1,0].set_ylabel('f(t)')
        axes[1,0].legend()
        axes[1,0].grid(True, alpha=0.3)

        # Plot 4: Energy comparison bar chart
        axes[1,1].bar(['Time Domain\n∫|f(t)|²dt',
                       'Freq Domain\n∫|F(f)|²df'],
                      [E_time, E_freq],
                      color=['blue', 'red'], alpha=0.7)
        axes[1,1].set_title(f'Parseval Energy Comparison\n'
                            f'Time={E_time:.4f}, Freq={E_freq:.4f}')
        axes[1,1].set_ylabel('Energy')
        axes[1,1].grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()


# ══════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════

if __name__ == "__main__":

    # Time axis: covers [-3, 3] where signal is defined
    t = np.linspace(-3, 3, 2000)

    # Frequency axis: wide enough to capture signal energy
    f = np.linspace(-20, 20, 2000)

    verifier = ParsevalVerifier(t, f)
    verifier.run()