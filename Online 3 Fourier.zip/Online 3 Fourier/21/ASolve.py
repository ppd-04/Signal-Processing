import numpy as np
import matplotlib.pyplot as plt
from imageio.v2 import imread

# ══════════════════════════════════════════════
# ImageLoader — load and store the image
# Same idea as your ContinuousImage class
# ══════════════════════════════════════════════

class ImageLoader:

    def __init__(self, image_path):
        """
        Load image as grayscale, normalize to [0, 1].
        Same as your ContinuousImage.__init__()
        """
        img        = imread(image_path, mode='L').astype(float)
        self.image = img / np.max(img)      # normalize: 0 to 1
        self.rows  = self.image.shape[0]    # number of rows
        self.cols  = self.image.shape[1]    # number of columns

    def show(self, title="Image"):
        plt.figure()
        plt.imshow(self.image, cmap='gray')
        plt.title(title)
        plt.axis('off')
        plt.show()


# ══════════════════════════════════════════════
# RowFT — Fourier Transform row by row
# Hint says: "Apply FT row by row"
# ══════════════════════════════════════════════

class RowFT:

    def __init__(self, image):
        """
        image : 2D numpy array (the grayscale image)
        """
        self.image = image
        self.rows  = image.shape[0]
        self.cols  = image.shape[1]

        # Frequency axis for each row
        # Each row has 'cols' pixels
        # Frequencies go from -cols/2 to +cols/2
        self.freqs = np.fft.fftfreq(self.cols)  
        # Wait — can't use fft!
        # Use manual frequency axis instead:
        self.freqs = np.linspace(-0.5, 0.5, self.cols)

    def compute_ft_rows(self):
        """
        Apply 1D Fourier Transform to EACH ROW separately.

        Why row by row?
        → Hint says so!
        → Noise often appears as patterns along rows
        → Row-by-row FT reveals these patterns

        For each row:
          row_signal = image[row, :]   (one row of pixels)
          FT of that row → spectrum of that row

        Result: 2D array of spectrums
                shape = (num_rows, num_cols)
                Each row in result = FT of that image row
        """
        # Storage for FT results
        # Complex array: FT values are complex numbers
        FT = np.zeros((self.rows, self.cols), dtype=complex)

        for row_idx in range(self.rows):

            # Get one row of the image
            row_signal = self.image[row_idx, :]

            # Compute FT of this row
            # Same formula as always:
            # X(f) = ∫ x(t) · e^(-j2πft) dt
            # But here t = pixel index, f = frequency
            for i, fi in enumerate(self.freqs):

                # pixel positions (0, 1, 2, ..., cols-1)
                pixels = np.arange(self.cols)

                # test wave at frequency fi
                kernel   = np.exp(-1j * 2 * np.pi * fi * pixels)

                # integrate using trapz
                FT[row_idx, i] = np.trapezoid(row_signal * kernel,
                                               pixels)

        return FT

    def apply_lowpass_filter(self, FT, cutoff=0.1):
        """
        LOW-PASS FILTER:
        Keep frequencies BELOW cutoff → keep the letter
        Remove frequencies ABOVE cutoff → remove noise

        cutoff = 0.1 means:
          Keep  |f| ≤ 0.1  (low freq → smooth → letter)
          Remove |f| > 0.1  (high freq → noise → remove)

        This is OPPOSITE of your high_pass filter!
        Your high_pass: removes low, keeps high → edges
        This low_pass:  removes high, keeps low → clean image
        """
        FT_filtered = FT.copy()

        for i, fi in enumerate(self.freqs):
            if np.abs(fi) > cutoff:        # if frequency is too high
                FT_filtered[:, i] = 0      # zero out that frequency column

        return FT_filtered

    def compute_ift_rows(self, FT_filtered):
        """
        Inverse FT row by row to reconstruct the image.

        IFT formula:
        x(t) = ∫ X(f) · e^(+j2πft) df

        SAME as FT but +j instead of -j
        and integrate over frequencies instead of pixels.
        """
        reconstructed = np.zeros((self.rows, self.cols))

        for row_idx in range(self.rows):

            # Get FT of this row
            row_FT = FT_filtered[row_idx, :]

            # IFT: sum over all frequencies
            row_signal = np.zeros(self.cols, dtype=complex)

            pixels = np.arange(self.cols)

            for j, pix in enumerate(pixels):
                # +j for inverse! (opposite sign from forward FT)
                kernel         = np.exp(+1j * 2 * np.pi
                                        * self.freqs * pix)
                row_signal[j]  = np.trapezoid(row_FT * kernel,
                                               self.freqs)

            # Take real part (imaginary should be ≈ 0)
            reconstructed[row_idx, :] = np.real(row_signal)

        return reconstructed


# ══════════════════════════════════════════════
# Denoiser — puts it all together
# ══════════════════════════════════════════════

class ImageDenoiser:

    def __init__(self, image_path):
        self.loader = ImageLoader(image_path)
        self.image  = self.loader.image
        self.rft    = RowFT(self.image)

    def run(self, cutoff=0.1):
        """
        Full pipeline:
        1. Load image
        2. FT row by row
        3. Look at spectrum (find noise)
        4. Apply low-pass filter
        5. IFT row by row
        6. Show clean image
        """

        print("Step 1: Image loaded.")
        print(f"  Shape: {self.image.shape}")

        print("Step 2: Computing FT row by row...")
        FT          = self.rft.compute_ft_rows()

        print("Step 3: Applying low-pass filter...")
        FT_filtered = self.rft.apply_lowpass_filter(FT,
                                                     cutoff=cutoff)

        print("Step 4: Computing IFT row by row...")
        clean       = self.rft.compute_ift_rows(FT_filtered)

        print("Step 5: Plotting results...")
        self.plot(self.image, FT, FT_filtered, clean)

        return clean

    def plot(self, noisy, FT, FT_filtered, clean):
        """
        4 plots:
        1. Original noisy image
        2. FT magnitude (shows noise frequencies as spikes)
        3. Filtered FT magnitude (spikes removed)
        4. Reconstructed clean image
        """
        fig, axes = plt.subplots(2, 2, figsize=(13, 9))
        fig.suptitle("Image Denoising Using Fourier Transform",
                     fontsize=13, fontweight='bold')

        # Plot 1: Noisy input
        axes[0,0].imshow(noisy, cmap='gray')
        axes[0,0].set_title('Noisy Image (Input)')
        axes[0,0].axis('off')

        # Plot 2: FT magnitude — shows where noise is
        # Average across rows to see overall spectrum
        avg_spectrum = np.mean(np.abs(FT), axis=0)
        axes[0,1].plot(self.rft.freqs, avg_spectrum)
        axes[0,1].set_title('Average Row Spectrum |FT|\n'
                             'Spikes = Noise Frequencies')
        axes[0,1].set_xlabel('Frequency')
        axes[0,1].set_ylabel('Magnitude')
        axes[0,1].grid(True, alpha=0.3)

        # Plot 3: Filtered FT magnitude
        avg_filtered = np.mean(np.abs(FT_filtered), axis=0)
        axes[1,0].plot(self.rft.freqs, avg_filtered)
        axes[1,0].set_title('Filtered Spectrum\n'
                             '(High frequencies removed)')
        axes[1,0].set_xlabel('Frequency')
        axes[1,0].set_ylabel('Magnitude')
        axes[1,0].grid(True, alpha=0.3)

        # Plot 4: Clean reconstructed image — the secret letter!
        axes[1,1].imshow(clean, cmap='gray')
        axes[1,1].set_title('Denoised Image (Secret Letter!)')
        axes[1,1].axis('off')

        plt.tight_layout()
        plt.show()


# ══════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════

if __name__ == "__main__":
    import sys

    image_path = sys.argv[1] if len(sys.argv) > 1 else "noisy_image.png"
    cutoff     = float(sys.argv[2]) if len(sys.argv) > 2 else 0.1

    denoiser = ImageDenoiser(image_path)
    clean    = denoiser.run(cutoff=cutoff)