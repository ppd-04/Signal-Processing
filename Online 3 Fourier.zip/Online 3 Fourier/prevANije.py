import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(-10, 10, 5000)
f = np.linspace(-5, 5, 1000)

x = 0.5*np.cos(4*t)+0.5*np.sin(6*t)
y1 =  -2.0*np.sin(4*t) + 3.0*np.cos(6*t)   # dx/dt
y2 =  -8.0*np.cos(4*t) - 18.0*np.sin(6*t)  # d²x/dt²
y3 =  32.0*np.sin(4*t) - 108.0*np.cos(6*t)

def cft(signal, t, f):
    X = np.zeros(len(f), dtpye=complex)
    for i, fi in enumerate(f):
        kernal = np.cos(2*np.pi*fi*t)-1j*np.sin(2*np.pi*fi*t)
        X[i]=np.trapezoid(signal*kernal, t)
    return X
