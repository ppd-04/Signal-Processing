import numpy as np
import matplotlib.pyplot as plt

# ── time and frequency axes ──
t = np.linspace(-10, 10, 5000)
f = np.linspace(-5,   5, 1000)

# ── signals (manual derivatives) ──
x  =   0.5*np.cos(4*t) + 0.5*np.sin(6*t)
y1 =  -2.0*np.sin(4*t) + 3.0*np.cos(6*t)   # dx/dt
y2 =  -8.0*np.cos(4*t) - 18.0*np.sin(6*t)  # d²x/dt²
y3 =  32.0*np.sin(4*t) - 108.0*np.cos(6*t) # d³x/dt³

# ── 1D CFT (one function, used for everything) ──
def cft(signal, t, f):
    X = np.zeros(len(f), dtype=complex)
    for i, fi in enumerate(f):
        kernel = np.cos(2*np.pi*fi*t) - 1j*np.sin(2*np.pi*fi*t)
        X[i]   = np.trapezoid(signal * kernel, t)
    return X

# ── compute all CFTs ──
X_f  = cft(x,  t, f)
Y1_f = cft(y1, t, f)
Y2_f = cft(y2, t, f)
Y3_f = cft(y3, t, f)

# ── theoretical predictions using property ──
j2pif     = 1j * 2 * np.pi * f
Y1_theory = j2pif    * X_f
Y2_theory = j2pif**2 * X_f
Y3_theory = j2pif**3 * X_f

# ── MSE ──
def mse(a, b):
    return np.mean(np.abs(a - b)**2)

print("===== MSE RESULTS =====")
for name, direct, theory in [
        ("1st", Y1_f, Y1_theory),
        ("2nd", Y2_f, Y2_theory),
        ("3rd", Y3_f, Y3_theory)]:
    print(f"{name} → Mag MSE: {mse(np.abs(direct), np.abs(theory)):.4e} "
          f"| Phase MSE: {mse(np.angle(direct), np.angle(theory)):.4e}")

# ── plot ──
fig, axes = plt.subplots(3, 2, figsize=(12, 10))
fig.suptitle("Differentiation Property Verification")

for row, (direct, theory, title) in enumerate([
        (Y1_f, Y1_theory, "1st Derivative"),
        (Y2_f, Y2_theory, "2nd Derivative"),
        (Y3_f, Y3_theory, "3rd Derivative")]):

    axes[row,0].plot(f, np.abs(direct),     'b-',  lw=2, label='Direct', alpha=0.7)
    axes[row,0].plot(f, np.abs(theory),     'r--', lw=1, label='Theory')
    axes[row,0].set_title(f"{title} Magnitude")
    axes[row,0].legend(); axes[row,0].grid(True, alpha=0.3)

    axes[row,1].plot(f, np.angle(direct),   'b-',  lw=2, label='Direct', alpha=0.7)
    axes[row,1].plot(f, np.angle(theory),   'r--', lw=1, label='Theory')
    axes[row,1].set_title(f"{title} Phase")
    axes[row,1].legend(); axes[row,1].grid(True, alpha=0.3)

plt.tight_layout()
plt.show()