import numpy as np
import matplotlib.pyplot as plt

# ════════════════════════════════════════════════════
# SignalGenerator class
# Generates square, triangle, and combined signals
# Also handles time compression + phase shift
# ════════════════════════════════════════════════════

class SignalGenerator:

    def __init__(self, t):
        """
        t : time axis array
        """
        self.t = t

    def square(self):
        """
        Square wave: 1 if |t| <= 0.5, else 0
        
        Looks like:
              ┌───┐
        ──────┘   └──────
        -0.5      0.5
        """
        return np.where(np.abs(self.t) <= 0.5, 1.0, 0.0)

    def triangle(self):
        """
        Triangle wave: 1 - |t| if |t| <= 1, else 0
        
        Looks like:
            /\
           /  \
        --/    \--
        -1      1
        """
        return np.where(np.abs(self.t) <= 1.0,
                        1.0 - np.abs(self.t), 0.0)

    def combined(self):
        """
        x(t) = Square(t) + Triangle(t)
        Just add both signals together
        """
        return self.square() + self.triangle()

    def apply_operations(self, f0, a):
        """
        Apply BOTH operations to x(t):

        Step 1: Time compress by a
                Replace t with a*t in the signal
                → x(at) means use (a × original_t) as input

        Step 2: Phase shift by 2πf0t
                Multiply by e^(j2πf0t)
                → complex multiplication

        Result: y(t) = x(at) × e^(j2πf0t)

        f0 : frequency shift amount (10)
        a  : time compression factor (10)
        """
        # Save original time axis
        original_t = self.t

        # Step 1: compress time → use a*t as the new time
        # x(at) means: evaluate x at positions (a × t)
        self.t     = a * original_t   # replace t with at
        x_compressed = self.combined()  # compute x(at)

        # Restore original t
        self.t     = original_t

        # Step 2: multiply by e^(j2πf0t)
        # e^(j2πf0t) = cos(2πf0t) + j*sin(2πf0t)
        phase_shift = np.exp(1j * 2 * np.pi * f0 * self.t)

        # y(t) = x(at) × e^(j2πf0t)
        y           = x_compressed * phase_shift

        return y


# ════════════════════════════════════════════════════
# CFTAnalyzer class
# Computes CFT and interpolates spectrum
# ════════════════════════════════════════════════════

class CFTAnalyzer:

    def __init__(self, t, f):
        """
        t : time axis
        f : frequency axis
        """
        self.t = t
        self.f = f

    def compute(self, signal):
        """
        CFT using trapezoid integration.
        X(f) = ∫ x(t) · e^(-j2πft) dt

        For each frequency fi:
          kernel = cos(2πfit) - j·sin(2πfit)
          X[i]   = trapezoid(signal × kernel, t)

        Note: signal can be complex (y(t) is complex!)
        trapezoid handles complex arrays fine.
        """
        X = np.zeros(len(self.f), dtype=complex)

        for i, fi in enumerate(self.f):
            kernel = np.cos(2*np.pi*fi*self.t) \
                   - 1j*np.sin(2*np.pi*fi*self.t)
            X[i]   = np.trapezoid(signal * kernel, self.t)

        return X

    def magnitude(self, X):
        """ |X(f)| """
        return np.abs(X)

    def phase(self, X):
        """ ∠X(f) in radians """
        return np.angle(X)

    def interpolate_spectrum(self, X, f_original, f_new):
        """
        We need X((f - f0)/a) — evaluated at shifted/scaled frequencies.

        Problem: X is computed at self.f points.
                 We need it at (f - f0)/a points.
                 These might not align exactly!

        Solution: INTERPOLATE
                  Use existing X values to estimate
                  values at the new frequency points.

        X         : computed CFT array
        f_original: the frequency axis X was computed on
        f_new     : the new frequency points we need values at
        """
        # Real and imaginary parts separately
        # (np.interp works only on real numbers)
        real_interp = np.interp(f_new,
                                f_original, np.real(X),
                                left=0, right=0)
        imag_interp = np.interp(f_new,
                                f_original, np.imag(X),
                                left=0, right=0)
        return real_interp + 1j * imag_interp


# ════════════════════════════════════════════════════
# MSE function
# ════════════════════════════════════════════════════

def mse(a, b):
    """
    MSE = (1/N) × Σ(a - b)²
    """
    return np.mean((a - b)**2)


# ════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════

# Parameters
t  = np.linspace(-5, 5, 2000)    # time axis
f  = np.linspace(-10, 10, 1000)  # frequency axis
f0 = 10                           # frequency shift
a  = 10                           # time compression

# ── Generate signals ──
gen = SignalGenerator(t)

# Original signal: x(t) = Square(t) + Triangle(t)
x   = gen.combined()              # real signal

# Modified signal: y(t) = x(at) × e^(j2πf0t)
y   = gen.apply_operations(f0=f0, a=a)   # complex signal!

# ── Compute CFTs ──
analyzer = CFTAnalyzer(t, f)

print("Computing CFT of x(t)...")
X_f = analyzer.compute(x)         # CFT of original

print("Computing CFT of y(t)...")
Y_f = analyzer.compute(y)         # CFT of modified

# ── Theoretical prediction ──
# Property: Y(f) = (1/|a|) × X((f - f0)/a)
#
# Step 1: compute (f - f0)/a for each f point
f_shifted   = (f - f0) / a        # new frequency argument
#
# Step 2: evaluate X at these new frequency points
# X was computed at f points, now we need it at f_shifted points
X_shifted   = analyzer.interpolate_spectrum(X_f, f, f_shifted)
#
# Step 3: scale by 1/|a|
Y_theory    = (1/np.abs(a)) * X_shifted

# ── Magnitudes and Phases ──
mag_Y        = analyzer.magnitude(Y_f)        # |Y(f)| measured
mag_theory   = analyzer.magnitude(Y_theory)  # (1/|a|)|X((f-f0)/a)|

phase_Y      = analyzer.phase(Y_f)           # ∠Y(f) measured
phase_theory = analyzer.phase(Y_theory)      # ∠X((f-f0)/a)

# ── MSE ──
mse_mag   = mse(mag_Y, mag_theory)
mse_phase = mse(phase_Y, phase_theory)

print("\n========== MSE RESULTS ==========")
print(f"Magnitude MSE : {mse_mag:.6e}")
print(f"Phase MSE     : {mse_phase:.6e}")
print("==================================")

# ── Plots ──
fig, axes = plt.subplots(2, 2, figsize=(13, 9))
fig.suptitle("Scaling + Modulation Property: y(t) = x(at)·e^(j2πf0t)",
             fontsize=13, fontweight='bold')

# Top-left: Magnitude comparison
axes[0,0].plot(f, mag_Y,      'b-',  lw=2,   label='|Y(f)| measured')
axes[0,0].plot(f, mag_theory, 'r--', lw=1.5, label='(1/|a|)|X((f-f0)/a)| theory')
axes[0,0].set_title(f'Magnitude (MSE={mse_mag:.2e})')
axes[0,0].set_xlabel('Frequency f')
axes[0,0].set_ylabel('Magnitude')
axes[0,0].legend()
axes[0,0].grid(True, alpha=0.3)

# Top-right: Phase comparison
axes[0,1].plot(f, phase_Y,      'b-',  lw=2,   label='∠Y(f) measured')
axes[0,1].plot(f, phase_theory, 'r--', lw=1.5, label='∠X((f-f0)/a) theory')
axes[0,1].set_title(f'Phase (MSE={mse_phase:.2e})')
axes[0,1].set_xlabel('Frequency f')
axes[0,1].set_ylabel('Phase (rad)')
axes[0,1].legend()
axes[0,1].grid(True, alpha=0.3)

# Bottom-left: Original signal x(t) in time domain
axes[1,0].plot(t, x, 'b-', lw=2, label='x(t) = Square + Triangle')
axes[1,0].set_title('Original Signal x(t)')
axes[1,0].set_xlabel('Time t')
axes[1,0].set_ylabel('Amplitude')
axes[1,0].legend()
axes[1,0].grid(True, alpha=0.3)

# Bottom-right: |X(f)| vs |Y(f)| to see shift+scale effect
axes[1,1].plot(f, analyzer.magnitude(X_f), 'b-',  lw=2,
               label='|X(f)| original')
axes[1,1].plot(f, mag_Y,                   'r--', lw=1.5,
               label='|Y(f)| shifted+scaled')
axes[1,1].set_title('Spectrum: Before vs After')
axes[1,1].set_xlabel('Frequency f')
axes[1,1].set_ylabel('Magnitude')
axes[1,1].legend()
axes[1,1].grid(True, alpha=0.3)

plt.tight_layout()
plt.show()