import numpy as np
import matplotlib.pyplot as plt

# ════════════════════════════════════════════
# SignalGenerator class
# Generates different types of signals
# ════════════════════════════════════════════

class SignalGenerator:
    
    def __init__(self, t):
        """
        t : time axis array
        Store it so all methods can use it
        """
        self.t = t
    
    def gaussian(self, a):
        """
        Generate Gaussian signal: x(t) = e^(-a*t²)
        
        a controls the WIDTH:
        - Large a → narrow/sharp Gaussian
        - Small a → wide/flat Gaussian
        """
        return np.exp(-a * self.t**2)
    
    def time_shift(self, signal_fn, a, t0):
        """
        Shift a signal by t0:
        y(t) = x(t - t0)
        
        How? Replace t with (t - t0) in the signal function.
        
        signal_fn : the function that generates the signal
        a         : parameter for that function (e.g., a for gaussian)
        t0        : time shift amount
        
        We do NOT manually shift arrays.
        We call the function with (t - t0) as input.
        """
        # Save original t
        original_t = self.t
        
        # Replace t with (t - t0) → this IS the time shift
        self.t     = original_t - t0
        
        # Generate signal with shifted time
        shifted    = signal_fn(a)
        
        # Restore original t
        self.t     = original_t
        
        return shifted


# ════════════════════════════════════════════
# CFTAnalyzer class
# Computes CFT using trapezoid integration
# Same idea as previous problem's cft() function
# but wrapped in a class
# ════════════════════════════════════════════

class CFTAnalyzer:
    
    def __init__(self, t, f):
        """
        t : time axis
        f : frequency axis
        """
        self.t = t
        self.f = f
    
    def compute(self, signal):
        """
        Compute CFT of signal using trapezoid integration.
        
        X(f) = ∫ x(t) · e^(-j2πft) dt
             = ∫ x(t) · [cos(2πft) - j·sin(2πft)] dt
        
        Same concept as previous problem!
        For each frequency fi:
          - build kernel = cos(2πfit) - j·sin(2πfit)
          - multiply signal × kernel
          - integrate using trapezoid
        """
        X = np.zeros(len(self.f), dtype=complex)
        
        for i, fi in enumerate(self.f):
            kernel = np.cos(2*np.pi*fi*self.t) \
                   - 1j*np.sin(2*np.pi*fi*self.t)
            X[i]   = np.trapezoid(signal * kernel, self.t)
        
        return X
    
    def magnitude(self, X):
        """
        |X(f)| = sqrt(real² + imag²)
        np.abs() does this for complex numbers
        """
        return np.abs(X)
    
    def phase(self, X):
        """
        ∠X(f) = arctan(imag / real)
        np.angle() does this for complex numbers
        Returns values in [-π, π]
        """
        return np.angle(X)


# ════════════════════════════════════════════
# MSE function
# ════════════════════════════════════════════

def mse(a, b):
    """
    MSE = (1/N) × Σ(a - b)²
    Small MSE → a and b are nearly identical
    """
    return np.mean((a - b)**2)


# ════════════════════════════════════════════
# MAIN: Run everything
# ════════════════════════════════════════════

# ── Part 1 & 2: Time axis and original signal ──

t  = np.linspace(-5, 5, 2000)    # time axis: -5 to 5, 2000 points
f  = np.linspace(-10, 10, 1000)  # frequency axis: -10 to 10, 1000 points
t0 = 1                            # time shift amount

# Create signal generator with time axis
gen = SignalGenerator(t)

# Generate original Gaussian signal: x(t) = e^(-t²), a=1
x   = gen.gaussian(a=1)

# ── Part 3: Time-shifted signal ──

# y(t) = x(t - 1) = e^(-(t-1)²)
# Using OOP framework (time_shift method)
y   = gen.time_shift(gen.gaussian, a=1, t0=t0)

# ── Part 4: Compute CFTs ──

analyzer = CFTAnalyzer(t, f)

print("Computing CFT of x(t)...")
X_f = analyzer.compute(x)        # CFT of original signal

print("Computing CFT of y(t)...")
Y_f = analyzer.compute(y)        # CFT of shifted signal

# ── Part 5: Magnitudes and Phases ──

mag_X   = analyzer.magnitude(X_f)       # |X(f)|
mag_Y   = analyzer.magnitude(Y_f)       # |Y(f)|
phase_X = analyzer.phase(X_f)           # ∠X(f)
phase_Y = analyzer.phase(Y_f)           # ∠Y(f)

# Theoretical phase prediction from time-shift property:
# ∠Y(f) = ∠X(f) - 2πf×t0
phase_Y_theory = phase_X - 2*np.pi*f*t0

# ── Part 6: MSE ──

# Magnitude MSE: should be ≈ 0 (time shift doesn't change magnitude)
mse_mag   = mse(mag_X, mag_Y)

# Phase MSE: compare measured phase vs theoretical prediction
mse_phase = mse(phase_Y, phase_Y_theory)

print("\n========== MSE RESULTS ==========")
print(f"Magnitude MSE : {mse_mag:.6e}")
print(f"Phase MSE     : {mse_phase:.6e}")
print("==================================")

if mse_mag < 1e-6:
    print("✓ Magnitude MSE is near zero → time shift does NOT affect magnitude")
if mse_phase < 1e-4:
    print("✓ Phase MSE is near zero → phase shifts linearly with frequency")

# ── Plotting ──

fig, axes = plt.subplots(2, 2, figsize=(13, 9))
fig.suptitle("Time-Shift Property Verification: y(t) = x(t-1)",
             fontsize=13, fontweight='bold')

# Top-left: Magnitude spectra
axes[0,0].plot(f, mag_X, 'b-',  lw=2,   label='|X(f)| original')
axes[0,0].plot(f, mag_Y, 'r--', lw=1.5, label='|Y(f)| shifted')
axes[0,0].set_title('Magnitude Spectra (should overlap perfectly)')
axes[0,0].set_xlabel('Frequency f (Hz)')
axes[0,0].set_ylabel('|X(f)|, |Y(f)|')
axes[0,0].legend()
axes[0,0].grid(True, alpha=0.3)

# Top-right: Phase spectra
axes[0,1].plot(f, phase_X,        'b-',  lw=2,   label='∠X(f) original')
axes[0,1].plot(f, phase_Y,        'r--', lw=1.5, label='∠Y(f) shifted')
axes[0,1].plot(f, phase_Y_theory, 'g:',  lw=2,   label='∠X(f)-2πft0 theory')
axes[0,1].set_title('Phase Spectra')
axes[0,1].set_xlabel('Frequency f (Hz)')
axes[0,1].set_ylabel('Phase (radians)')
axes[0,1].legend()
axes[0,1].grid(True, alpha=0.3)

# Bottom-left: Signals in time domain (just to visualize)
axes[1,0].plot(t, x, 'b-',  lw=2,   label='x(t) = e^(-t²)')
axes[1,0].plot(t, y, 'r--', lw=1.5, label='y(t) = e^(-(t-1)²)')
axes[1,0].set_title('Time Domain Signals')
axes[1,0].set_xlabel('Time t')
axes[1,0].set_ylabel('Amplitude')
axes[1,0].legend()
axes[1,0].grid(True, alpha=0.3)

# Bottom-right: Phase difference verification
# ∠Y(f) - ∠X(f) should equal -2πft0 (straight line)
phase_diff          = phase_Y - phase_X          # measured difference
phase_diff_theory   = -2 * np.pi * f * t0        # theoretical: straight line

axes[1,1].plot(f, phase_diff,        'r-',  lw=2,   label='∠Y(f) - ∠X(f) measured')
axes[1,1].plot(f, phase_diff_theory, 'g--', lw=1.5, label='-2πft0 theory')
axes[1,1].set_title('Phase Difference (should be straight line -2πft0)')
axes[1,1].set_xlabel('Frequency f (Hz)')
axes[1,1].set_ylabel('Phase difference (rad)')
axes[1,1].legend()
axes[1,1].grid(True, alpha=0.3)

plt.tight_layout()
plt.show()